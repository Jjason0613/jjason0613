/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Trophy, Flame, RotateCcw, Play, Sparkles, 
  HelpCircle, Info, RefreshCw, Star, Share2, Volume2, VolumeX, ShieldAlert
} from 'lucide-react';

import { ActiveShape, CellCoordinate, ShapeTemplate, GameState } from './types';
import { sfx } from './lib/audio';
import { getRandomShapeTemplate, SHAPE_TEMPLATES, getFruitForColor } from './lib/shapes';
import { ScoreBoard } from './components/ScoreBoard';
import { GameGrid } from './components/GameGrid';
import { ShapeContainer } from './components/ShapeContainer';
import { JuiceCanvas, JuiceCanvasRef } from './components/JuiceCanvas';
import { FruitCell } from './components/FruitCell';
import { DEFAULT_SKINS } from './lib/fruitSkins';
import { FruitSkinWorkshop } from './components/FruitSkinWorkshop';

const ROWS = 10;
const COLS = 8;

export default function App() {
  // --- Grid State ---
  const [grid, setGrid] = useState<(string | null)[][]>(() => 
    Array.from({ length: ROWS }, () => Array(COLS).fill(null))
  );

  // --- Score & Streak ---
  const [score, setScore] = useState<number>(0);
  const [highScore, setHighScore] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('gridfit_high_score');
      return saved ? parseInt(saved, 10) : 0;
    } catch {
      return 0;
    }
  });
  const [streak, setStreak] = useState<number>(0);
  const [clearBonusLevel, setClearBonusLevel] = useState<number>(1);
  const [clearedAnyInRound, setClearedAnyInRound] = useState<boolean>(false);
  const [stats, setStats] = useState({
    shapesPlaced: 0,
    linesCleared: 0,
    revivesUsed: 0,
  });

  // --- Active Shapes (3 Dock Slots) ---
  const [activeShapes, setActiveShapes] = useState<ActiveShape[]>([]);

  // --- Interaction States ---
  const [selectedShapeId, setSelectedShapeId] = useState<string | null>(null);
  const [selectedTemplate, setSelectedTemplate] = useState<ShapeTemplate | null>(null);

  // Dragging States
  const [draggedShape, setDraggedShape] = useState<ActiveShape | null>(null);
  const [dragPosition, setDragPosition] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [hoveredCell, setHoveredCell] = useState<CellCoordinate | null>(null);
  
  // Visual Effects
  const [clearingCells, setClearingCells] = useState<Set<string>>(new Set());
  const [screenShakeActive, setScreenShakeActive] = useState<boolean>(false);
  
  // Game Lifecycle
  const [isGameOver, setIsGameOver] = useState<boolean>(false);
  const [hasRevived, setHasRevived] = useState<boolean>(false);
  const [isSelectingReviveArea, setIsSelectingReviveArea] = useState<boolean>(false);
  const [reviveHoverCell, setReviveHoverCell] = useState<CellCoordinate | null>(null);

  // Settings
  const [isMusicMuted, setIsMusicMuted] = useState<boolean>(true); // start muted to comply with web autoplay standards
  const [isSfxMuted, setIsSfxMuted] = useState<boolean>(false);
  const [musicType, setMusicType] = useState<'synth' | 'mp3'>('synth');
  const [isFruitTheme, setIsFruitTheme] = useState<boolean>(true);
  const [selectedSkins, setSelectedSkins] = useState<Record<string, string>>(() => {
    try {
      const saved = localStorage.getItem('gridfit_selected_skins');
      return saved ? JSON.parse(saved) : DEFAULT_SKINS;
    } catch {
      return DEFAULT_SKINS;
    }
  });

  const handleSelectSkin = (templateName: string, skinId: string) => {
    setSelectedSkins(prev => {
      const updated = { ...prev, [templateName]: skinId };
      try {
        localStorage.setItem('gridfit_selected_skins', JSON.stringify(updated));
      } catch (e) {
        console.error("Storage error:", e);
      }
      return updated;
    });
  };

  // Guide overlay
  const [showGuide, setShowGuide] = useState<boolean>(false);

  // --- Refs ---
  const juiceCanvasRef = useRef<JuiceCanvasRef | null>(null);
  const gridRectRef = useRef<DOMRect | null>(null);
  const dragPointerIdRef = useRef<number | null>(null);
  const hoveredCellRef = useRef<CellCoordinate | null>(null);
  const draggedShapeVisualRef = useRef<HTMLDivElement | null>(null);

  // --- Initializer ---
  useEffect(() => {
    generateNewSetOfShapes();
    // Pre-mute configurations
    sfx.toggleMusic(isMusicMuted);
    sfx.toggleSfx(isSfxMuted);
  }, []);

  // Sync high score to local storage
  useEffect(() => {
    if (score > highScore) {
      setHighScore(score);
      try {
        localStorage.setItem('gridfit_high_score', score.toString());
      } catch (e) {
        console.error("Storage error:", e);
      }
    }
  }, [score, highScore]);

  // --- Game Loop Helpers ---

  // Helper to generate a set of 3 shapes where AT LEAST one shape has a valid move on the grid.
  function generateSetWithValidMove(currentGrid: (string | null)[][]): ActiveShape[] {
    let shapes: ActiveShape[] = Array.from({ length: 3 }).map(() => ({
      id: Math.random().toString(),
      template: getRandomShapeTemplate(),
      used: false,
    }));

    // Check if there is at least one valid move for any of the generated shapes
    const canFit = (shs: ActiveShape[]) => {
      return shs.some(shape => {
        for (let r = 0; r < ROWS; r++) {
          for (let c = 0; c < COLS; c++) {
            if (isValidPlacement(currentGrid, shape.template, r, c)) {
              return true;
            }
          }
        }
        return false;
      });
    };

    let attempts = 0;
    while (!canFit(shapes) && attempts < 100) {
      shapes = Array.from({ length: 3 }).map(() => ({
        id: Math.random().toString(),
        template: getRandomShapeTemplate(),
        used: false,
      }));
      attempts++;
    }

    // Fallback: If after 100 attempts no complex shape fits, replace the last shape with a Single Dot (1x1), 
    // which is guaranteed to fit as long as there is at least one empty square on the board.
    if (!canFit(shapes)) {
      let hasEmptyCell = false;
      for (let r = 0; r < ROWS; r++) {
        for (let c = 0; c < COLS; c++) {
          if (currentGrid[r][c] === null) {
            hasEmptyCell = true;
            break;
          }
        }
        if (hasEmptyCell) break;
      }

      if (hasEmptyCell) {
        const singleDot = SHAPE_TEMPLATES.find(s => s.blocks.length === 1);
        if (singleDot) {
          shapes[2] = {
            id: Math.random().toString(),
            template: singleDot,
            used: false,
          };
        }
      }
    }

    return shapes;
  }

  // Spawns 3 random shapes in the dock, ensuring at least one possible move is always available!
  const generateNewSetOfShapes = () => {
    const shapes = generateSetWithValidMove(grid);
    setActiveShapes(shapes);
    
    // Check if new set can fit on current board
    checkGameOverState(grid, shapes);
  };

  // Check if any shape can still fit on the grid
  const checkGameOverState = (currentGrid: (string | null)[][], shapes: ActiveShape[]) => {
    const unplacedShapes = shapes.filter(s => !s.used);
    
    // If all shapes are already used, a new set will be spawned anyway, so it's not game over
    if (unplacedShapes.length === 0) return;

    // Scan the entire 8x10 board for any cell that can anchor the shape
    const canFitAny = unplacedShapes.some((shape) => {
      for (let r = 0; r < ROWS; r++) {
        for (let c = 0; c < COLS; c++) {
          if (isValidPlacement(currentGrid, shape.template, r, c)) {
            return true; // found at least one place!
          }
        }
      }
      return false;
    });

    if (!canFitAny) {
      setIsGameOver(true);
      sfx.playGameOver();
    }
  };

  // Core geometric fitting check
  const isValidPlacement = (
    currentGrid: (string | null)[][],
    template: ShapeTemplate,
    startRow: number,
    startCol: number
  ): boolean => {
    // Check if all blocks of the shape can land on empty cells
    return template.blocks.every((block) => {
      const targetRow = startRow + block.row;
      const targetCol = startCol + block.col;

      // Check bounds
      if (targetRow < 0 || targetRow >= ROWS || targetCol < 0 || targetCol >= COLS) {
        return false;
      }

      // Check overlap
      return currentGrid[targetRow][targetCol] === null;
    });
  };

  // --- Handlers ---

  // Select shape for Tap-to-Place (Click fallback)
  const handleSelectShape = (id: string, template: ShapeTemplate) => {
    sfx.playClick();
    if (selectedShapeId === id) {
      // Toggle off
      setSelectedShapeId(null);
      setSelectedTemplate(null);
    } else {
      setSelectedShapeId(id);
      setSelectedTemplate(template);
    }
  };

  // Clicking a grid cell (handles placement of selected shape OR 3x3 Revive Blast)
  const handleGridCellClick = (row: number, col: number) => {
    // 1. Revive Area Selection Mode
    if (isSelectingReviveArea) {
      triggerReviveBlast(row, col);
      return;
    }

    // 2. Standard Tap-to-Place Mode
    if (selectedShapeId && selectedTemplate) {
      // For Tap-To-Place, let's treat the clicked cell as the anchor (top-left) of the shape.
      if (isValidPlacement(grid, selectedTemplate, row, col)) {
        placeShape(selectedShapeId, selectedTemplate, row, col);
        setSelectedShapeId(null);
        setSelectedTemplate(null);
      } else {
        // Play error sound/click to notify invalid
        sfx.playClick();
      }
    }
  };

  // Core placing execution
  const placeShape = (shapeId: string, template: ShapeTemplate, targetRow: number, targetCol: number) => {
    sfx.playThwack();

    // 1. Update Grid
    const newGrid = grid.map(r => [...r]);
    template.blocks.forEach((block) => {
      const r = targetRow + block.row;
      const c = targetCol + block.col;
      newGrid[r][c] = `${template.color}:${template.name}:${block.row}:${block.col}`;
    });

    // 2. Mark shape as used
    const updatedShapes = activeShapes.map((s) => 
      s.id === shapeId ? { ...s, used: true } : s
    );

    // 3. Compute Placement Score
    const blockPoints = template.blocks.length * 10;
    let turnScore = blockPoints;
    
    // Spawn float text for placing
    if (juiceCanvasRef.current) {
      // Calculate coordinate for text spawn (approximate)
      const gridEl = document.getElementById('gridfit-grid-cells');
      if (gridEl) {
        const rect = gridEl.getBoundingClientRect();
        const textX = ((targetCol + template.width / 2) / COLS) * rect.width;
        const textY = ((targetRow + template.height / 2) / ROWS) * rect.height;
        juiceCanvasRef.current.spawnText(`+${blockPoints}`, textX, textY, template.color, false);
      }
    }

    setStats(prev => ({ ...prev, shapesPlaced: prev.shapesPlaced + 1 }));

    // 4. Scan and clear rows/columns
    scanAndClearLines(newGrid, turnScore, updatedShapes);
  };

  // Scans for filled rows & columns and executes simultaneous clearing with satisfying particles
  const scanAndClearLines = (
    currentGrid: (string | null)[][],
    scoreAcquired: number,
    updatedShapes: ActiveShape[]
  ) => {
    const fullRows: number[] = [];
    const fullCols: number[] = [];

    // Scan Rows
    for (let r = 0; r < ROWS; r++) {
      if (currentGrid[r].every(cell => cell !== null)) {
        fullRows.push(r);
      }
    }

    // Scan Cols
    for (let c = 0; c < COLS; c++) {
      let isFull = true;
      for (let r = 0; r < ROWS; r++) {
        if (currentGrid[r][c] === null) {
          isFull = false;
          break;
        }
      }
      if (isFull) {
        fullCols.push(c);
      }
    }

    const linesClearedCount = fullRows.length + fullCols.length;

    const isFourRowsClear = fullRows.length >= 4;

    if (linesClearedCount > 0) {
      // Build streak & multiplier
      const nextStreak = streak + 1;
      const streakBonus = nextStreak * 50;
      
      // Clear bonus gets better every single time!
      // level 1 = 1x, level 2 = 1.5x, level 3 = 2x, etc. (+50% per level!)
      const clearBonusMultiplier = 1 + (clearBonusLevel - 1) * 0.5;
      const baseComboScore = isFourRowsClear ? 2000 : (linesClearedCount * 100 * linesClearedCount);
      const comboScore = Math.round(baseComboScore * clearBonusMultiplier);
      const finalTurnScore = scoreAcquired + comboScore + streakBonus;

      setStreak(nextStreak);
      setClearedAnyInRound(true);
      setClearBonusLevel(prev => prev + 1);
      setScore(prev => prev + finalTurnScore);
      setStats(prev => ({ ...prev, linesCleared: prev.linesCleared + linesClearedCount }));

      // Setup cells to trigger flashing CSS transitions
      const clearingSet = new Set<string>();
      if (isFourRowsClear) {
        // If 4 rows are cleared, ALL existing blocks disappear! We add them all to the clearing set for full-board particle impact
        for (let r = 0; r < ROWS; r++) {
          for (let c = 0; c < COLS; c++) {
            if (currentGrid[r][c] !== null) {
              clearingSet.add(`${r},${c}`);
            }
          }
        }
      } else {
        fullRows.forEach(r => {
          for (let c = 0; c < COLS; c++) clearingSet.add(`${r},${c}`);
        });
        fullCols.forEach(c => {
          for (let r = 0; r < ROWS; r++) clearingSet.add(`${r},${c}`);
        });
      }

      setClearingCells(clearingSet);
      setScreenShakeActive(true);
      
      if (isFourRowsClear) {
        sfx.playRevive(); // Play the gorgeous sparkling chime sound for full-board wipe!
      } else {
        sfx.playLineClear(linesClearedCount);
      }

      // Trigger high-performance canvas particles for every cleared block
      const gridEl = document.getElementById('gridfit-grid-cells');
      if (gridEl && juiceCanvasRef.current) {
        const rect = gridEl.getBoundingClientRect();
        const cellW = rect.width / COLS;
        const cellH = rect.height / ROWS;

        // Spawn flying score badge
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        const labelText = isFourRowsClear 
          ? `4-ROW BOARD CLEAR! +2000` 
          : (linesClearedCount > 1 
              ? `COMBO x${linesClearedCount}! +${comboScore}` 
              : `CLEAR! +${comboScore}`);
        
        juiceCanvasRef.current.spawnText(labelText, centerX, centerY - 20, isFourRowsClear ? '#10b981' : '#facc15', true);
        if (nextStreak > 1) {
          setTimeout(() => {
            if (juiceCanvasRef.current) {
              juiceCanvasRef.current.spawnText(`STREAK x${nextStreak}! +${streakBonus}`, centerX, centerY + 20, '#f97316', false);
            }
          }, 300);
        }

        // Spawn particles
        clearingSet.forEach((key) => {
          const [r, c] = key.split(',').map(Number);
          const blockColorRaw = currentGrid[r][c] || '#ffffff';
          const blockColor = blockColorRaw.includes(':') ? blockColorRaw.split(':')[0] : blockColorRaw;
          if (juiceCanvasRef.current) {
            juiceCanvasRef.current.spawnParticles(r, c, blockColor, cellW, cellH);
          }
        });
      }

      // After visual flash delay (350ms), empty cells out completely from grid state
      setTimeout(() => {
        const clearedGrid = currentGrid.map((rowArr, r) => {
          return rowArr.map((cellVal, c) => {
            if (isFourRowsClear) {
              return null; // All blocks disappear!
            }
            const isCleared = fullRows.includes(r) || fullCols.includes(c);
            return isCleared ? null : cellVal;
          });
        });

        setGrid(clearedGrid);
        setClearingCells(new Set());
        setScreenShakeActive(false);

        // Advance Dock States
        finalizeTurnState(clearedGrid, updatedShapes);
      }, 350);

    } else {
      // No clears: add placed shape score (streak lasts until the round of 3 blocks completes)
      setScore(prev => prev + scoreAcquired);

      // Advance Dock States
      setGrid(currentGrid);
      finalizeTurnState(currentGrid, updatedShapes);
    }
  };

  // Finalizes turn: checking if all 3 shapes used to trigger spawning a fresh set, ensuring at least one shape has a valid move.
  const finalizeTurnState = (currentGrid: (string | null)[][], updatedShapes: ActiveShape[]) => {
    const allUsed = updatedShapes.every((s) => s.used);
    
    if (allUsed) {
      // Check if user cleared any lines in this entire 3-block set!
      if (!clearedAnyInRound) {
        setStreak(0);
      }
      setClearedAnyInRound(false);

      // Regenerate 3 shapes with at least one guaranteed possible move
      const nextShapes = generateSetWithValidMove(currentGrid);
      setActiveShapes(nextShapes);
      checkGameOverState(currentGrid, nextShapes);
    } else {
      setActiveShapes(updatedShapes);
      checkGameOverState(currentGrid, updatedShapes);
    }
  };

  // --- Smooth Pointer Dragging Mechanics (Absolute positioning) ---

  const handlePointerDownShape = (e: React.PointerEvent, shapeId: string, template: ShapeTemplate) => {
    e.preventDefault();
    const activeShape = activeShapes.find(s => s.id === shapeId);
    if (!activeShape || activeShape.used || isSelectingReviveArea) return;

    setSelectedShapeId(null); // Clear selected state if any
    setSelectedTemplate(null);

    // Measure grid coordinates immediately
    const gridEl = document.getElementById('gridfit-grid-cells');
    if (gridEl) {
      gridRectRef.current = gridEl.getBoundingClientRect();
    }

    // Set dragging state
    setDraggedShape(activeShape);
    dragPointerIdRef.current = e.pointerId;

    // Capture pointer events to keep tracking even outside target boundaries
    e.currentTarget.setPointerCapture(e.pointerId);

    // Initial floating coordinates (centered, lifted 70px above pointer)
    const VERTICAL_OFFSET = 70;
    setDragPosition({ x: e.clientX, y: e.clientY - VERTICAL_OFFSET });
    hoveredCellRef.current = null;
  };

  const handlePointerMoveShape = (e: React.PointerEvent) => {
    if (!draggedShape || dragPointerIdRef.current !== e.pointerId) return;

    const pointerX = e.clientX;
    const pointerY = e.clientY;
    const VERTICAL_OFFSET = 70;

    // 1. Direct DOM update for zero lag
    if (draggedShapeVisualRef.current) {
      draggedShapeVisualRef.current.style.left = `${pointerX}px`;
      draggedShapeVisualRef.current.style.top = `${pointerY}px`;
    }

    // Snapping Calculation:
    // Align shape center slightly above finger tip so visual isn't blocked
    const gridRect = gridRectRef.current;
    if (!gridRect) return;

    const cellW = gridRect.width / COLS;
    const cellH = gridRect.height / ROWS;

    // Center shape under cursor, but shifted upwards (Classic puzzle mechanic)
    const shapePixelWidth = templateWidth(draggedShape.template) * cellW;
    const shapePixelHeight = templateHeight(draggedShape.template) * cellH;
    
    // Virtual top-left pixel coord of shape
    const dragX = pointerX - (shapePixelWidth / 2);
    const dragY = (pointerY - VERTICAL_OFFSET) - (shapePixelHeight / 2);

    // Relative to grid left/top
    const relX = dragX - gridRect.left;
    const relY = dragY - gridRect.top;

    // Get closest column & row index
    const hoverCol = Math.round(relX / cellW);
    const hoverRow = Math.round(relY / cellH);

    // Calculate next hovered cell
    let nextHoverCell: CellCoordinate | null = null;
    if (isValidPlacement(grid, draggedShape.template, hoverRow, hoverCol)) {
      nextHoverCell = { row: hoverRow, col: hoverCol };
    }

    // Only set state if the snapped cell actually changed! (Reduces re-renders from 120fps to <5fps)
    const currentHover = hoveredCellRef.current;
    const hasChanged = !currentHover || !nextHoverCell
      ? (!!currentHover !== !!nextHoverCell)
      : (currentHover.row !== nextHoverCell.row || currentHover.col !== nextHoverCell.col);

    if (hasChanged) {
      hoveredCellRef.current = nextHoverCell;
      setHoveredCell(nextHoverCell);
    }
  };

  const handlePointerUpShape = (e: React.PointerEvent) => {
    if (!draggedShape || dragPointerIdRef.current !== e.pointerId) return;

    e.currentTarget.releasePointerCapture(e.pointerId);

    const finalHoveredCell = hoveredCellRef.current;

    // If hover is valid, snap and place!
    if (finalHoveredCell) {
      placeShape(draggedShape.id, draggedShape.template, finalHoveredCell.row, finalHoveredCell.col);
    } else {
      // Snap back click sound
      sfx.playClick();
    }

    // Reset drag states
    setDraggedShape(null);
    setHoveredCell(null);
    hoveredCellRef.current = null;
    dragPointerIdRef.current = null;
  };

  const templateWidth = (t: ShapeTemplate) => t.width;
  const templateHeight = (t: ShapeTemplate) => t.height;

  // --- Revive 3x3 Blast Mechanics ---

  // Triggered when clicking a cell during Revive selection state
  const triggerReviveBlast = (centerRow: number, centerCol: number) => {
    // Blast a 3x3 grid centered around (centerRow, centerCol)
    const newGrid = grid.map(r => [...r]);
    const cellsToBlast: string[] = [];

    for (let r = centerRow - 1; r <= centerRow + 1; r++) {
      for (let c = centerCol - 1; c <= centerCol + 1; c++) {
        if (r >= 0 && r < ROWS && c >= 0 && c < COLS) {
          if (newGrid[r][c] !== null) {
            cellsToBlast.push(`${r},${c}`);
            newGrid[r][c] = null;
          }
        }
      }
    }

    setIsSelectingReviveArea(false);
    setGrid(newGrid);
    setHasRevived(true);
    setStats(prev => ({ ...prev, revivesUsed: prev.revivesUsed + 1 }));

    // Sound and particle celebration!
    sfx.playRevive();
    setScreenShakeActive(true);

    const gridEl = document.getElementById('gridfit-grid-cells');
    if (gridEl && juiceCanvasRef.current) {
      const rect = gridEl.getBoundingClientRect();
      const cellW = rect.width / COLS;
      const cellH = rect.height / ROWS;

      // Floating text
      juiceCanvasRef.current.spawnText("REVIVED!", rect.width / 2, rect.height / 2, '#ef4444', true);

      // Particles for blasted blocks
      cellsToBlast.forEach((key) => {
        const [r, c] = key.split(',').map(Number);
        if (juiceCanvasRef.current) {
          juiceCanvasRef.current.spawnParticles(r, c, '#ffffff', cellW, cellH);
          // also add random color particles
          juiceCanvasRef.current.spawnParticles(r, c, '#f43f5e', cellW, cellH);
        }
      });
    }

    setTimeout(() => {
      setScreenShakeActive(false);
      // Run game-over validation check again after revive
      checkGameOverState(newGrid, activeShapes);
    }, 400);
  };

  // --- Restart Game ---
  const handleRestart = () => {
    sfx.playClick();
    executeReset();
  };

  const executeReset = () => {
    setGrid(Array.from({ length: ROWS }, () => Array(COLS).fill(null)));
    setScore(0);
    setStreak(0);
    setClearBonusLevel(1);
    setClearedAnyInRound(false);
    setStats({ shapesPlaced: 0, linesCleared: 0, revivesUsed: 0 });
    setHasRevived(false);
    setIsGameOver(false);
    setIsSelectingReviveArea(false);
    setHoveredCell(null);
    setSelectedShapeId(null);
    setSelectedTemplate(null);
    generateNewSetOfShapes();
  };

  // --- Sound / Music toggles ---
  const handleToggleMusic = () => {
    const nextMute = !isMusicMuted;
    setIsMusicMuted(nextMute);
    sfx.toggleMusic(nextMute);
  };

  const handleToggleMusicType = () => {
    sfx.playClick();
    const nextType = musicType === 'synth' ? 'mp3' : 'synth';
    setMusicType(nextType);
    sfx.setMusicType(nextType);
  };

  const handleToggleSfx = () => {
    const nextMute = !isSfxMuted;
    setIsSfxMuted(nextMute);
    sfx.toggleSfx(nextMute);
    sfx.playClick();
  };

  const handleToggleFruitTheme = () => {
    sfx.playClick();
    setIsFruitTheme(prev => !prev);
  };

  // Share High Score simulated
  const handleShare = () => {
    sfx.playClick();
    if (navigator.share) {
      navigator.share({
        title: 'GridFit Puzzle',
        text: `I scored ${score} points in GridFit! Can you beat my high score?`,
        url: window.location.href,
      }).catch(console.error);
    } else {
      // Fallback: Copy to clipboard
      navigator.clipboard.writeText(`I scored ${score} points in GridFit! Can you beat my high score? Try it at ${window.location.href}`);
      if (juiceCanvasRef.current) {
        const gridEl = document.getElementById('gridfit-grid-cells');
        if (gridEl) {
          const rect = gridEl.getBoundingClientRect();
          juiceCanvasRef.current.spawnText("Link copied to clipboard!", rect.width / 2, rect.height / 2, '#10b981', false);
        }
      }
    }
  };

  return (
    <div className="min-h-screen relative overflow-x-hidden flex flex-col justify-start items-center p-3 sm:p-5 select-none text-white pb-10">
      {/* Animated beautiful ambient background */}
      <div className="animated-mesh-bg" />

      {/* Main UI shell constraint with responsive grid layout */}
      <div 
        id="gridfit-game-shell"
        className={`w-full max-w-md md:max-w-4xl flex flex-col md:grid md:grid-cols-12 gap-4 md:gap-6 relative transition-transform duration-200 ${
          screenShakeActive ? 'screen-shake' : ''
        }`}
      >
        {/* ScoreBoard wrapper (Right column on desktop, first on mobile) */}
        <div className="w-full order-1 md:col-span-5 md:col-start-8 md:row-start-1">
          <ScoreBoard
            score={score}
            highScore={highScore}
            streak={streak}
            streakMultiplier={streak > 0 ? 1 : 0}
            isMusicMuted={isMusicMuted}
            isSfxMuted={isSfxMuted}
            musicType={musicType}
            clearBonusLevel={clearBonusLevel}
            isFruitTheme={isFruitTheme}
            onToggleMusic={handleToggleMusic}
            onToggleSfx={handleToggleSfx}
            onRestart={handleRestart}
            onToggleMusicType={handleToggleMusicType}
            onToggleFruitTheme={handleToggleFruitTheme}
          />
        </div>

        {/* 3x3 Revive Instructions Banner wrapper (Left column on desktop, second on mobile) */}
        {isSelectingReviveArea && (
          <div className="w-full order-2 md:col-span-7 md:col-start-1 md:row-start-1">
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="w-full bg-rose-500/10 border border-rose-500/40 text-rose-300 rounded-xl p-3 text-center text-xs font-semibold tracking-wide animate-pulse flex items-center justify-center gap-1.5"
            >
              <Sparkles className="w-4 h-4 text-rose-400 animate-spin" />
              SELECT ANY CELL ON THE GRID TO BLAST A 3X3 AREA!
            </motion.div>
          </div>
        )}

        {/* Dynamic Game Board area wrapper (Left column on desktop, third on mobile) */}
        <div className={`w-full order-3 md:col-span-7 md:col-start-1 relative aspect-[8/10] max-w-md mx-auto ${
          isSelectingReviveArea ? 'md:row-start-2 md:row-span-3' : 'md:row-start-1 md:row-span-3'
        }`}>
          {/* Main Board Grid */}
          <GameGrid
            grid={grid}
            draggedShape={draggedShape ? draggedShape.template : null}
            hoveredCell={hoveredCell}
            clearingCells={clearingCells}
            selectedDockShape={selectedTemplate}
            isFruitTheme={isFruitTheme}
            selectedSkins={selectedSkins}
            onCellClick={handleGridCellClick}
          />

          {/* High performance Visual Effect layer */}
          <JuiceCanvas
            ref={juiceCanvasRef}
            onShakeEnd={() => setScreenShakeActive(false)}
          />

          {/* Absolute floating element overlay during pointer drag */}
          {draggedShape && (
            <div
              ref={draggedShapeVisualRef}
              className="fixed pointer-events-none z-50 transition-transform duration-75 origin-center scale-100 opacity-90"
              style={{
                left: `${dragPosition.x}px`,
                top: `${dragPosition.y}px`,
                transform: 'translate(-50%, -50%)', // Centered around the pointer/calculated offset
              }}
            >
              {/* Floating render of dragged shape */}
              <div
                className="grid gap-[2.5px]"
                style={{
                  gridTemplateColumns: `repeat(${draggedShape.template.width}, minmax(0, 1fr))`,
                }}
              >
                {Array.from({ length: draggedShape.template.height }).map((_, r) => {
                  return Array.from({ length: draggedShape.template.width }).map((_, c) => {
                    const hasBlock = draggedShape.template.blocks.some((b) => b.row === r && b.col === c);
                    
                    // Render miniature block mirroring grid aspect ratio perfectly
                    const cellWidth = gridRectRef.current ? (gridRectRef.current.width / COLS) : 36;
                    const cellHeight = gridRectRef.current ? (gridRectRef.current.height / ROWS) : 36;
                    const sizeStyle = { 
                      width: `${cellWidth}px`, 
                      height: `${cellHeight}px` 
                    };

                    if (!hasBlock) {
                      return <div key={`${r}-${c}`} style={sizeStyle} className="opacity-0" />;
                    }

                    const skinId = isFruitTheme ? (selectedSkins[draggedShape.template.name] || DEFAULT_SKINS[draggedShape.template.name]) : '';

                    return (
                      <div
                        key={`${r}-${c}`}
                        className="rounded-[6px] border-t border-white/25 shadow-2xl block-glow relative flex items-center justify-center overflow-hidden"
                        style={{
                          ...sizeStyle,
                          backgroundColor: skinId ? undefined : draggedShape.template.color,
                          borderColor: skinId ? 'transparent' : 'rgba(255, 255, 255, 0.3)',
                          ['--glow-color' as any]: `${draggedShape.template.color}60`,
                        }}
                      >
                        {isFruitTheme && skinId ? (
                          <FruitCell
                            skinId={skinId}
                            row={r}
                            col={c}
                            width={draggedShape.template.width}
                            height={draggedShape.template.height}
                            color={draggedShape.template.color}
                            cellSize={cellWidth}
                          />
                        ) : (
                          <>
                            <div className="absolute inset-x-0 top-0 h-[35%] bg-gradient-to-b from-white/20 to-transparent rounded-t-[5px]" />
                            {isFruitTheme && (
                              <span 
                                style={{ fontSize: `${cellWidth * 0.7}px` }}
                                className="select-none leading-none z-10"
                              >
                                {getFruitForColor(draggedShape.template.color).emoji}
                              </span>
                            )}
                          </>
                        )}
                      </div>
                    );
                  });
                })}
              </div>
            </div>
          )}
        </div>

        {/* Dock holding 3 pieces wrapper (Right column on desktop, fourth on mobile) */}
        <div className="w-full order-4 md:col-span-5 md:col-start-8 md:row-start-2">
          <ShapeContainer
            activeShapes={activeShapes}
            selectedShapeId={selectedShapeId}
            isFruitTheme={isFruitTheme}
            selectedSkins={selectedSkins}
            onSelectShape={handleSelectShape}
            onPointerDownShape={handlePointerDownShape}
          />
        </div>

        {/* Fruit Skin Workshop Panel wrapper */}
        <div className="w-full order-5 md:col-span-5 md:col-start-8 md:row-start-3">
          <FruitSkinWorkshop
            isFruitTheme={isFruitTheme}
            onToggleFruitTheme={() => setIsFruitTheme(!isFruitTheme)}
            selectedSkins={selectedSkins}
            onSelectSkin={handleSelectSkin}
          />
        </div>

        {/* Help guide toggler & Panel wrapper */}
        <div className="w-full order-6 md:col-span-5 md:col-start-8 md:row-start-4 flex flex-col gap-3">
          <div className="w-full flex justify-center items-center gap-1.5 mt-1">
            <button
              onClick={() => { sfx.playClick(); setShowGuide(!showGuide); }}
              className="flex items-center gap-1 text-[11px] font-mono text-slate-400 hover:text-slate-200 transition cursor-pointer"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              How to Play
            </button>
          </div>

          {/* Guide Panel */}
          <AnimatePresence>
            {showGuide && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="w-full bg-slate-900/40 border border-white/10 rounded-2xl p-4 text-xs text-slate-300 flex flex-col gap-2 font-sans overflow-hidden shadow-lg"
              >
                <h4 className="font-semibold text-white font-display text-sm">Rules & Strategy:</h4>
                <p>1. **Drag and drop** or **Tap** the 3 shapes at the bottom onto the 8x10 grid board.</p>
                <p>2. Fill entire **rows** or **columns** to instantly clear them, freeing grid space and earning score combos.</p>
                <p>3. Fitting all three dock shapes will trigger another set of three.</p>
                <p>4. Clearing lines on consecutive turns builds a **Streak Gauge** giving massive bonus points.</p>
                <p>5. **Super Board Wipe**: Destroying **4 rows at once** sweeps all blocks from the board and awards a flat **2,000 points**!</p>
                <p>6. The match ends when none of the available shapes can fit into the empty spaces on the board.</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* =========================================================================
          4. OVERLAYS & MODALS (MONETIZATION & GAME OVER STATS)
         ========================================================================= */}
      
      {/* Standard Game Over Stats Sheet */}
      <AnimatePresence>
        {isGameOver && !isSelectingReviveArea && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-40 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="w-full max-w-sm rounded-3xl glass-card p-6 border border-white/10 text-center relative flex flex-col items-center"
            >
              <div className="w-16 h-16 rounded-full bg-rose-500/10 flex items-center justify-center mb-4 text-rose-500">
                <ShieldAlert className="w-9 h-9 animate-bounce" />
              </div>

              <h2 className="text-3xl font-black tracking-wide font-display bg-gradient-to-r from-rose-400 to-pink-500 bg-clip-text text-transparent">
                GAME OVER
              </h2>
              <p className="text-xs text-slate-400 mt-1 uppercase font-mono tracking-wider">
                No legal moves remain
              </p>

              {/* Score Display Grid */}
              <div className="w-full bg-slate-950/60 border border-white/5 rounded-2xl p-4 my-5 flex flex-col gap-3.5">
                <div className="flex justify-between items-center">
                  <span className="text-xs text-slate-400 font-medium">Final Score</span>
                  <span className="text-2xl font-bold font-mono text-white tracking-wide">{score}</span>
                </div>
                
                <div className="flex justify-between items-center border-t border-white/5 pt-3">
                  <div className="flex items-center gap-1 text-xs text-slate-400">
                    <Trophy className="w-3.5 h-3.5 text-amber-400" />
                    <span>Best Score</span>
                  </div>
                  <span className="text-sm font-semibold font-mono text-amber-300">{highScore}</span>
                </div>

                <div className="grid grid-cols-2 gap-2 border-t border-white/5 pt-3 text-[10px] text-slate-400 font-mono">
                  <div className="bg-slate-900/50 p-2 rounded-lg text-left">
                    <span className="block text-slate-500 text-[8px] uppercase">Shapes Placed</span>
                    <span className="text-xs font-bold text-slate-300 mt-0.5 block">{stats.shapesPlaced}</span>
                  </div>
                  <div className="bg-slate-900/50 p-2 rounded-lg text-left">
                    <span className="block text-slate-500 text-[8px] uppercase">Lines Cleared</span>
                    <span className="text-xs font-bold text-slate-300 mt-0.5 block">{stats.linesCleared}</span>
                  </div>
                </div>
              </div>

              {/* Core Options / Next Steps */}
              <div className="w-full flex flex-col gap-2 mt-2">
                {/* 1. Optional Free Second Chance */}
                {!hasRevived && (
                  <button
                    id="gameover-revive-btn"
                    onClick={() => { sfx.playClick(); setIsSelectingReviveArea(true); }}
                    className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 text-slate-950 font-extrabold tracking-wide text-sm shadow-lg hover:brightness-110 active:scale-[0.98] transition flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Star className="w-4 h-4 fill-slate-950 text-slate-950 animate-spin" />
                    Second Chance (Free 3x3 Blast)
                  </button>
                )}

                {/* 2. Standard Play Again restart */}
                <button
                  id="gameover-restart-btn"
                  onClick={executeReset}
                  className={`w-full py-3 px-4 rounded-xl font-bold tracking-wide text-sm active:scale-[0.98] transition flex items-center justify-center gap-2 ${
                    hasRevived 
                      ? 'bg-gradient-to-r from-indigo-500 to-sky-500 text-white hover:brightness-110 shadow-lg' 
                      : 'bg-white/10 hover:bg-white/15 border border-white/10 text-white'
                  }`}
                >
                  <RotateCcw className="w-4 h-4" />
                  Play Again
                </button>

                {/* 3. Share score */}
                <button
                  id="gameover-share-btn"
                  onClick={handleShare}
                  className="w-full py-2.5 px-4 rounded-xl bg-slate-950/40 hover:bg-slate-950/70 border border-white/5 text-slate-300 font-semibold text-xs active:scale-[0.98] transition flex items-center justify-center gap-2"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  Share My Score
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Document Event Handlers for Dragging to prevent pointer losses */}
      {draggedShape && (
        <div
          className="fixed inset-0 z-40 select-none cursor-grabbing"
          style={{ touchAction: 'none' }}
          onPointerMove={handlePointerMoveShape}
          onPointerUp={handlePointerUpShape}
        />
      )}
    </div>
  );
}

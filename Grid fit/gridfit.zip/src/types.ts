/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface CellCoordinate {
  row: number;
  col: number;
}

export interface ShapeTemplate {
  name: string;
  // Relative coordinates of the blocks from the shape's local top-left anchor (0,0)
  blocks: CellCoordinate[];
  color: string;      // Tailwind class or hex
  bgClass: string;    // CSS background class
  borderClass: string;// CSS border class
  glowClass: string;  // Tailwind filter or drop-shadow class
  width: number;      // bound width
  height: number;     // bound height
}

export interface ActiveShape {
  id: string;
  template: ShapeTemplate;
  used: boolean;
}

export interface Particle {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  alpha: number;
  size: number;
  rotation: number;
  vRotation: number;
}

export interface FloatingText {
  id: string;
  text: string;
  x: number;
  y: number;
  alpha: number;
  scale: number;
}

export interface GameState {
  grid: (string | null)[][]; // 8 rows, 10 columns (or 10 rows, 8 columns? PRD says "8x10 rectangular grid", usually in mobile, width is 8 and height is 10)
  score: number;
  highScore: number;
  streak: number; // consecutive turns clearing lines
  streakMultiplier: number;
  consecutiveClears: number; // turn counter for streak
  activeShapes: ActiveShape[]; // 3 shapes
  isGameOver: boolean;
  hasRevived: boolean; // can revive once per game
  showReviveAd: boolean;
  showInterstitialAd: boolean;
  adsRemoved: boolean;
}

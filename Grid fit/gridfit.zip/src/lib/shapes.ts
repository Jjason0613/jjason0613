/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ShapeTemplate } from '../types';

export const SHAPE_TEMPLATES: ShapeTemplate[] = [
  // --- 1-BLOCK SHAPES ---
  {
    name: 'Single Dot',
    blocks: [{ row: 0, col: 0 }],
    color: '#f43f5e', // rose-500
    bgClass: 'bg-rose-500',
    borderClass: 'border-rose-400',
    glowClass: 'shadow-rose-500/50',
    width: 1,
    height: 1,
  },

  // --- 2-BLOCK SHAPES ---
  {
    name: 'Domino Horizontal',
    blocks: [{ row: 0, col: 0 }, { row: 0, col: 1 }],
    color: '#0ea5e9', // sky-500
    bgClass: 'bg-sky-500',
    borderClass: 'border-sky-400',
    glowClass: 'shadow-sky-500/50',
    width: 2,
    height: 1,
  },
  {
    name: 'Domino Vertical',
    blocks: [{ row: 0, col: 0 }, { row: 1, col: 0 }],
    color: '#0ea5e9',
    bgClass: 'bg-sky-500',
    borderClass: 'border-sky-400',
    glowClass: 'shadow-sky-500/50',
    width: 1,
    height: 2,
  },

  // --- 3-BLOCK SHAPES ---
  {
    name: 'Trio Horizontal',
    blocks: [{ row: 0, col: 0 }, { row: 0, col: 1 }, { row: 0, col: 2 }],
    color: '#22c55e', // emerald-500
    bgClass: 'bg-emerald-500',
    borderClass: 'border-emerald-400',
    glowClass: 'shadow-emerald-500/50',
    width: 3,
    height: 1,
  },
  {
    name: 'Trio Vertical',
    blocks: [{ row: 0, col: 0 }, { row: 1, col: 0 }, { row: 2, col: 0 }],
    color: '#22c55e',
    bgClass: 'bg-emerald-500',
    borderClass: 'border-emerald-400',
    glowClass: 'shadow-emerald-500/50',
    width: 1,
    height: 3,
  },
  {
    name: 'Small Corner L',
    blocks: [
      { row: 0, col: 0 },
      { row: 1, col: 0 }, { row: 1, col: 1 }
    ],
    color: '#eab308', // amber-500
    bgClass: 'bg-amber-500',
    borderClass: 'border-amber-400',
    glowClass: 'shadow-amber-500/50',
    width: 2,
    height: 2,
  },
  {
    name: 'Small Corner R',
    blocks: [
      { row: 0, col: 1 },
      { row: 1, col: 0 }, { row: 1, col: 1 }
    ],
    color: '#eab308',
    bgClass: 'bg-amber-500',
    borderClass: 'border-amber-400',
    glowClass: 'shadow-amber-500/50',
    width: 2,
    height: 2,
  },

  // --- 4-BLOCK SHAPES (TETROMINOS) ---
  {
    name: 'Tetromino Line H',
    blocks: [{ row: 0, col: 0 }, { row: 0, col: 1 }, { row: 0, col: 2 }, { row: 0, col: 3 }],
    color: '#a855f7', // purple-500
    bgClass: 'bg-purple-500',
    borderClass: 'border-purple-400',
    glowClass: 'shadow-purple-500/50',
    width: 4,
    height: 1,
  },
  {
    name: 'Tetromino Line V',
    blocks: [{ row: 0, col: 0 }, { row: 1, col: 0 }, { row: 2, col: 0 }, { row: 3, col: 0 }],
    color: '#a855f7',
    bgClass: 'bg-purple-500',
    borderClass: 'border-purple-400',
    glowClass: 'shadow-purple-500/50',
    width: 1,
    height: 4,
  },
  {
    name: 'Tetromino Square',
    blocks: [
      { row: 0, col: 0 }, { row: 0, col: 1 },
      { row: 1, col: 0 }, { row: 1, col: 1 }
    ],
    color: '#f97316', // orange-500
    bgClass: 'bg-orange-500',
    borderClass: 'border-orange-400',
    glowClass: 'shadow-orange-500/50',
    width: 2,
    height: 2,
  },
  {
    name: 'Tetromino T',
    blocks: [
      { row: 0, col: 1 },
      { row: 1, col: 0 }, { row: 1, col: 1 }, { row: 1, col: 2 }
    ],
    color: '#ec4899', // pink-500
    bgClass: 'bg-pink-500',
    borderClass: 'border-pink-400',
    glowClass: 'shadow-pink-500/50',
    width: 3,
    height: 2,
  },
  {
    name: 'Tetromino L-Left',
    blocks: [
      { row: 0, col: 0 },
      { row: 1, col: 0 },
      { row: 2, col: 0 }, { row: 2, col: 1 }
    ],
    color: '#3b82f6', // blue-500
    bgClass: 'bg-blue-500',
    borderClass: 'border-blue-400',
    glowClass: 'shadow-blue-500/50',
    width: 2,
    height: 3,
  },
  {
    name: 'Tetromino L-Right',
    blocks: [
      { row: 0, col: 1 },
      { row: 1, col: 1 },
      { row: 2, col: 0 }, { row: 2, col: 1 }
    ],
    color: '#3b82f6',
    bgClass: 'bg-blue-500',
    borderClass: 'border-blue-400',
    glowClass: 'shadow-blue-500/50',
    width: 2,
    height: 3,
  },
  {
    name: 'Tetromino Z',
    blocks: [
      { row: 0, col: 0 }, { row: 0, col: 1 },
      { row: 1, col: 1 }, { row: 1, col: 2 }
    ],
    color: '#14b8a6', // teal-500
    bgClass: 'bg-teal-500',
    borderClass: 'border-teal-400',
    glowClass: 'shadow-teal-500/50',
    width: 3,
    height: 2,
  },
  {
    name: 'Tetromino S',
    blocks: [
      { row: 0, col: 1 }, { row: 0, col: 2 },
      { row: 1, col: 0 }, { row: 1, col: 1 }
    ],
    color: '#14b8a6',
    bgClass: 'bg-teal-500',
    borderClass: 'border-teal-400',
    glowClass: 'shadow-teal-500/50',
    width: 3,
    height: 2,
  },

  // --- 5-BLOCK SHAPES (PENTOMINOS - CLASSIC HIGH DIFFICULTY!) ---
  {
    name: 'Pentomino Line H',
    blocks: [{ row: 0, col: 0 }, { row: 0, col: 1 }, { row: 0, col: 2 }, { row: 0, col: 3 }, { row: 0, col: 4 }],
    color: '#6366f1', // indigo-500
    bgClass: 'bg-indigo-500',
    borderClass: 'border-indigo-400',
    glowClass: 'shadow-indigo-500/50',
    width: 5,
    height: 1,
  },
  {
    name: 'Pentomino Line V',
    blocks: [{ row: 0, col: 0 }, { row: 1, col: 0 }, { row: 2, col: 0 }, { row: 3, col: 0 }, { row: 4, col: 0 }],
    color: '#6366f1',
    bgClass: 'bg-indigo-500',
    borderClass: 'border-indigo-400',
    glowClass: 'shadow-indigo-500/50',
    width: 1,
    height: 5,
  },
  {
    name: 'Big L-Corner 3x3',
    blocks: [
      { row: 0, col: 0 },
      { row: 1, col: 0 },
      { row: 2, col: 0 }, { row: 2, col: 1 }, { row: 2, col: 2 }
    ],
    color: '#d946ef', // fuchsia-500
    bgClass: 'bg-fuchsia-500',
    borderClass: 'border-fuchsia-400',
    glowClass: 'shadow-fuchsia-500/50',
    width: 3,
    height: 3,
  },
  {
    name: 'Pentomino Cross',
    blocks: [
      { row: 0, col: 1 },
      { row: 1, col: 0 }, { row: 1, col: 1 }, { row: 1, col: 2 },
      { row: 2, col: 1 }
    ],
    color: '#84cc16', // lime-500
    bgClass: 'bg-lime-500',
    borderClass: 'border-lime-400',
    glowClass: 'shadow-lime-500/50',
    width: 3,
    height: 3,
  },
];

// Map shape colors to corresponding fruit emojis/graphics
export function getFruitForColor(color: string): { emoji: string; name: string } {
  const lowercaseColor = color.toLowerCase();
  switch (lowercaseColor) {
    case '#f43f5e': return { emoji: '🍓', name: 'Strawberry' }; // rose-500
    case '#0ea5e9': return { emoji: '🫐', name: 'Blueberry' };  // sky-500
    case '#22c55e': return { emoji: '🍏', name: 'Green Apple' }; // emerald-500
    case '#eab308': return { emoji: '🍌', name: 'Nano Banana' }; // amber-500 (Google Nano Banana!)
    case '#a855f7': return { emoji: '🍇', name: 'Grapes' };      // purple-500
    case '#f97316': return { emoji: '🍊', name: 'Orange' };      // orange-500
    case '#ec4899': return { emoji: '🍒', name: 'Cherry' };      // pink-500
    case '#3b82f6': return { emoji: '🍍', name: 'Pineapple' };   // blue-500
    case '#14b8a6': return { emoji: '🍉', name: 'Watermelon' };  // teal-500
    case '#6366f1': return { emoji: '🍑', name: 'Peach' };       // indigo-500
    case '#d946ef': return { emoji: '🍈', name: 'Melon' };       // fuchsia-500
    case '#84cc16': return { emoji: '🍋', name: 'Lemon' };       // lime-500
    default: return { emoji: '🍌', name: 'Nano Banana' };
  }
}

// Returns a random shape template
export function getRandomShapeTemplate(): ShapeTemplate {
  // Classic 1010/Blockudoku shape selection.
  // We can weight shapes, so easier ones spawn a bit more, making the game very enjoyable and high-scoring.
  // Rose, Sky, Emerald, Amber shapes (1-3 blocks) have higher probability.
  // Pentominos (5 blocks) have lower probability to keep the game fair.
  const rand = Math.random();
  if (rand < 0.25) {
    // Return simple shapes (1-2 blocks)
    const easyShapes = SHAPE_TEMPLATES.filter(s => s.blocks.length <= 2);
    return easyShapes[Math.floor(Math.random() * easyShapes.length)];
  } else if (rand < 0.8) {
    // Return standard shapes (3-4 blocks)
    const standardShapes = SHAPE_TEMPLATES.filter(s => s.blocks.length === 3 || s.blocks.length === 4);
    return standardShapes[Math.floor(Math.random() * standardShapes.length)];
  } else {
    // Return complex pentominos / hard shapes
    const hardShapes = SHAPE_TEMPLATES.filter(s => s.blocks.length === 5);
    return hardShapes[Math.floor(Math.random() * hardShapes.length)];
  }
}

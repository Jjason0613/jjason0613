/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface FruitSkinConfig {
  id: string;
  name: string;
  textureName: string;
  description: string;
  howItCovers: string;
  funFact: string;
  emoji: string;
}

export const FRUIT_SKINS: Record<string, FruitSkinConfig[]> = {
  'Tetromino Square': [
    {
      id: 'lemon_wheel',
      name: 'Meyer Lemon Wheel',
      textureName: 'Lemon Texture',
      description: 'A cross-section slice of a Meyer lemon has a circular, segmented shape that naturally spans a 2x2 square canvas.',
      howItCovers: 'A large, thick-cut lemon round is laid flat over the entire 2x2 square face. The rind forms the perfect circular boundary inside the square, while the juicy pulp wedges radiate outwards from the center.',
      funFact: 'Meyer lemons are a cross between regular lemons and mandarin oranges, making them slightly sweeter and perfect for clean dessert designs.',
      emoji: '🍋'
    },
    {
      id: 'pineapple_ring',
      name: 'Pineapple Ring',
      textureName: 'Pineapple Texture',
      description: 'A round, juicy slice of pineapple with its core removed forms a golden ring that covers the square face.',
      howItCovers: 'The grid is covered with a continuous pineapple disk. The core cutout sits directly in the center of the 2x2 grid junction, while the fibrous radiating pattern covers the four face quarters.',
      funFact: 'Pineapples take almost three years to grow and mature into a single fruit, so use every square centimeter of its slice wisely!',
      emoji: '🍍'
    },
    {
      id: 'banana_slices',
      name: 'Banana Slices Grid',
      textureName: 'Banana Texture',
      description: 'Four thick, circular banana coins are packed tightly, one in each square of the 2x2 tetromino.',
      howItCovers: 'Four distinct coin slices of ripe banana are placed side-by-side, perfectly covering the face of each individual square unit in the 2x2 layout.',
      funFact: 'Bananas are technically berries! Their botanical classification makes them the most perfect, soft, square-filling berries around.',
      emoji: '🍌'
    }
  ],
  'Tetromino Line H': [
    {
      id: 'blueberry_skewer',
      name: 'Blueberry Skewer',
      textureName: 'Blueberry Texture',
      description: 'A perfectly straight line of giant, plump highbush blueberries, resting side-by-side to cover the long 1x4 face.',
      howItCovers: 'Four massive, frosted blueberries are aligned horizontally. Their dusty blue skin and crown-shaped calyxes face outwards to cover each of the 4 block segments.',
      funFact: "The powdery white coating on fresh blueberries is called the 'bloom.' It acts as a natural protective barrier!",
      emoji: '🫐'
    },
    {
      id: 'blue_java_banana_h',
      name: 'Blue Java Banana Segment',
      textureName: 'Banana Texture',
      description: 'A peeled section of the rare Blue Java Banana, known for its vanilla ice cream flavor and bluish tint.',
      howItCovers: 'A single long, continuous horizontal slice of the blue banana is carved precisely to a 1x4 rectangular aspect ratio, creating a smooth, creamy covering.',
      funFact: 'Blue Java Bananas can survive in freezing cold temperatures and have an incredibly creamy texture reminiscent of vanilla custard.',
      emoji: '🍌'
    },
    {
      id: 'blackberry_column_h',
      name: 'Blackberry Column',
      textureName: 'Blackberry Texture',
      description: 'A chain of deep dark purple/blue blackberries that fill the narrow length of the straight block.',
      howItCovers: 'A stack of glossy drupelets, lined up horizontally. The bumpy, reflective surface of the blackberries gives a rich, multi-faceted purple-cyan sheen to the line block.',
      funFact: 'Each tiny bump on a blackberry is called a drupelet, and each contains its own tiny seed!',
      emoji: '🍇'
    }
  ],
  'Tetromino Line V': [
    {
      id: 'blueberry_skewer_v',
      name: 'Blueberry Skewer',
      textureName: 'Blueberry Texture',
      description: 'A perfectly straight line of giant, plump highbush blueberries, resting side-by-side to cover the long 1x4 face.',
      howItCovers: 'Four massive, frosted blueberries are aligned vertically. Their dusty blue skin and crown-shaped calyxes face outwards to cover each of the 4 block segments.',
      funFact: "The powdery white coating on fresh blueberries is called the 'bloom.' It acts as a natural protective barrier!",
      emoji: '🫐'
    },
    {
      id: 'blue_java_banana_v',
      name: 'Blue Java Banana Segment',
      textureName: 'Banana Texture',
      description: 'A peeled section of the rare Blue Java Banana, known for its vanilla ice cream flavor and bluish tint.',
      howItCovers: 'A single long, continuous vertical slice of the blue banana is carved precisely to a 1x4 rectangular aspect ratio, creating a smooth, creamy covering.',
      funFact: 'Blue Java Bananas can survive in freezing cold temperatures and have an incredibly creamy texture reminiscent of vanilla custard.',
      emoji: '🍌'
    },
    {
      id: 'blackberry_column_v',
      name: 'Blackberry Column',
      textureName: 'Blackberry Texture',
      description: 'A chain of deep dark purple/blue blackberries that fill the narrow length of the straight block.',
      howItCovers: 'A stack of glossy drupelets, lined up vertically. The bumpy, reflective surface of the blackberries gives a rich, multi-faceted purple-cyan sheen to the line block.',
      funFact: 'Each tiny bump on a blackberry is called a drupelet, and each contains its own tiny seed!',
      emoji: '🍇'
    }
  ],
  'Tetromino S': [
    {
      id: 'strawberry',
      name: 'Fraise de Bois (Strawberry)',
      textureName: 'Strawberry Texture',
      description: 'Perfectfully ripened strawberry halves, cut lengthwise to match the dynamic curves of the S-shaped block.',
      howItCovers: 'Four flat-laid, heart-shaped strawberry halves are arranged into the staggered S-shape. Their tiny yellow achenes (seeds) create a wonderful dotted pattern, crowned with fresh green leafy caps.',
      funFact: 'Strawberries are the only fruit that wear their seeds on the outside - about 200 of them per berry!',
      emoji: '🍓'
    },
    {
      id: 'bing_cherry',
      name: 'Bing Cherry Halves',
      textureName: 'Cherry Texture',
      description: 'Dark, sweet cherries pitted and split open, creating circular deep-red pools along the zig-zag.',
      howItCovers: 'Four glossy, deep crimson cherry halves are nestled closely into the S-grid, their smooth reflective skin and deep red juices glistening.',
      funFact: 'A single cherry tree can produce up to 7,000 cherries in a harvest season—plenty to fill hundreds of tetrominos!',
      emoji: '🍒'
    }
  ],
  'Tetromino Z': [
    {
      id: 'kiwi_crosscut',
      name: 'Gold/Green Kiwi Cross-cut',
      textureName: 'Kiwi Texture',
      description: 'Vibrant green kiwifruit cross-cuts arranged to cover the staggered Z-block perfectly.',
      howItCovers: 'Four sliced kiwi wedges are tiled over the Z-shape. The creamy white centers, radiating fiber lines, and concentric rings of tiny black edible seeds wrap beautifully around the corners.',
      funFact: "Kiwifruit was originally known as the 'Chinese Gooseberry' before being renamed in New Zealand after the national bird.",
      emoji: '🥝'
    },
    {
      id: 'lime_slices',
      name: 'Persian Lime Slices',
      textureName: 'Lemon Texture',
      description: 'Tart, neon-green lime wheels sliced thin, overlapping slightly along the Z-grid.',
      howItCovers: 'Circular lime wheels are clipped into the Z-block frame. The translucent pulp segments give a highly geometric, clean citrus facade to the zig-zag.',
      funFact: "Limes contain high amounts of Vitamin C and were historically eaten by sailors to prevent scurvy, earning them the nickname 'limeys'.",
      emoji: '🍋'
    }
  ],
  'Tetromino L-Left': [
    {
      id: 'clementine_segments',
      name: 'Clementine / Mandarin Segments',
      textureName: 'Orange Texture',
      description: 'Plump, crescent-shaped Mandarin orange segments arranged to outline the upright L-shape.',
      howItCovers: 'The segments are aligned along the spine, with a broad segment completing the foot of the L. The glistening juice sacs under the translucent skin reflect golden light.',
      funFact: 'Mandarin oranges are ancestors of almost all modern citrus fruits, including sweet oranges and grapefruits!',
      emoji: '🍊'
    },
    {
      id: 'mango_cubes',
      name: 'Haden Mango Cubes',
      textureName: 'Mango Texture',
      description: "A classic 'hedgehog' sliced mango half, where the orange flesh is scored into cubes and popped outward.",
      howItCovers: 'Four massive, juicy, scored mango cubes are laid on the L-shape. The geometric grid cuts of the mango flesh align perfectly with the square units of the block!',
      funFact: "Mangoes are known as the 'King of Fruits' in many tropical cultures due to their rich culinary history and lush flavor.",
      emoji: '🥭'
    }
  ],
  'Tetromino L-Right': [
    {
      id: 'clementine_segments_r',
      name: 'Clementine / Mandarin Segments',
      textureName: 'Orange Texture',
      description: 'Plump, crescent-shaped Mandarin orange segments arranged to outline the upright L-shape.',
      howItCovers: 'The segments are aligned along the spine, with a broad segment completing the foot of the L. The glistening juice sacs under the translucent skin reflect golden light.',
      funFact: 'Mandarin oranges are ancestors of almost all modern citrus fruits, including sweet oranges and grapefruits!',
      emoji: '🍊'
    },
    {
      id: 'mango_cubes_r',
      name: 'Haden Mango Cubes',
      textureName: 'Mango Texture',
      description: "A classic 'hedgehog' sliced mango half, where the orange flesh is scored into cubes and popped outward.",
      howItCovers: 'Four massive, juicy, scored mango cubes are laid on the L-shape. The geometric grid cuts of the mango flesh align perfectly with the square units of the block!',
      funFact: "Mangoes are known as the 'King of Fruits' in many tropical cultures due to their rich culinary history and lush flavor.",
      emoji: '🥭'
    }
  ],
  'Tetromino T': [
    {
      id: 'plum_slices',
      name: 'Black Amber Plum Slices',
      textureName: 'Plum Texture',
      description: 'Deep royal purple plum skin with a sliver of golden-amber flesh visible along the edges.',
      howItCovers: 'Three broad slices of dark purple plum skin cover the horizontal crossbar of the T, while a fourth plum quarter extends down to cover the stem block.',
      funFact: 'Plums are closely related to peaches and almonds! When dried, they become prunes, which have been cultivated for thousands of years.',
      emoji: '🍑'
    },
    {
      id: 'blackberry_mosaic',
      name: 'Blackberry Mosaic',
      textureName: 'Blackberry Texture',
      description: 'A cluster of blackberries packed tightly to form a dark, pebbled texture covering the T-shape.',
      howItCovers: 'Tessellated blackberries form a bumpy, three-dimensional deep violet surface over the block. Light catches on each individual drupelet.',
      funFact: 'Blackberries are extremely high in antioxidants and have been used in traditional dyes to create deep, rich purple pigments.',
      emoji: '🍇'
    }
  ],
  'Single Dot': [
    {
      id: 'wild_raspberry',
      name: 'Single Wild Raspberry',
      textureName: 'Strawberry Texture',
      description: 'A single, hollow-cored red raspberry that nests perfectly over the compact 1x1 block space.',
      howItCovers: 'The raspberry is placed cap-downwards, with its crown facing up. Its bumpy texture completely encloses the 1x1 face.',
      funFact: 'Every raspberry contains about 100 individual drupelets, making this tiny 1x1 block look like a dense, glossy red crown.',
      emoji: '🍓'
    },
    {
      id: 'kumquat_round',
      name: 'Oval Kumquat Round',
      textureName: 'Orange Texture',
      description: 'A paper-thin horizontal slice of kumquat with its edible sweet rind enclosing the tiny block face.',
      howItCovers: 'Lay the orange-yellow kumquat slice flat in the center. The seedless, juicy pulp perfectly matches the 1x1 dimensions.',
      funFact: 'Unlike other citrus fruits, the rind of the kumquat is sweet, while the inner juice is famously tart!',
      emoji: '🍊'
    }
  ],
  'Domino Horizontal': [
    {
      id: 'apricot_slabs',
      name: 'Sweet Apricot Slabs',
      textureName: 'Mango Texture',
      description: 'Two sun-ripened apricot halves placed side-by-side to make a horizontal 1x2 bridge.',
      howItCovers: 'The velvety, pitted apricot cheeks are laid cut-side-down, offering a fuzzy, golden-orange landscape over both block segments.',
      funFact: 'Apricots have been cultivated for over 4,000 years and are known as symbols of prosperity in many cultures.',
      emoji: '🍑'
    },
    {
      id: 'fig_crosscut',
      name: 'Mission Fig Cross-Cut',
      textureName: 'Plum Texture',
      description: 'Two rich purple slices of Mission Fig with their deep pink, seed-speckled centers exposed.',
      howItCovers: 'Slices are laid flat on the 1x2 layout. The contrast between the dark purple skin and the vibrant pink pulp matches the block flawlessly.',
      funFact: 'Fig flowers actually bloom inside their pod-like fruits! They rely on specialized tiny wasps for pollination.',
      emoji: '🫐'
    }
  ],
  'Domino Vertical': [
    {
      id: 'plum_halves',
      name: 'Damsel Plum Halves',
      textureName: 'Plum Texture',
      description: 'Two rich, plump purple damson plum quarters stacked vertically to cover the 2x1 pillar.',
      howItCovers: 'The plum halves are aligned vertically, skin side up, showing off a deep royal-purple coat with a soft dusty bloom.',
      funFact: 'Damson plums are famous for their rich, astringent flavor which sweetens beautifully when cooked.',
      emoji: '🍑'
    },
    {
      id: 'kiwiberry_pillar',
      name: 'Kiwi-berry Pillar',
      textureName: 'Kiwi Texture',
      description: 'Two hairless baby kiwiberries halved vertically and stacked to fit the vertical 1x2 block.',
      howItCovers: 'Placed with cut faces facing up, revealing their intricate miniature kiwi seed patterns in a vertical chain.',
      funFact: 'Kiwiberries are grape-sized kiwis that can be eaten whole without peeling because they lack the fuzzy skin!',
      emoji: '🥝'
    }
  ],
  'Trio Horizontal': [
    {
      id: 'starfruit_slices_h',
      name: 'Starfruit Slices',
      textureName: 'Starfruit Texture',
      description: 'Three crisp, star-shaped yellow carambola slices lined up in a neat row.',
      howItCovers: 'Perfect five-pointed golden stars are laid flat on the 1x3 strip. The translucent yellow flesh with green edges catches the light beautifully.',
      funFact: 'Starfruit is entirely edible, including the skin, and gets its name from the star-like cross-section when sliced!',
      emoji: '⭐'
    },
    {
      id: 'guava_segments_h',
      name: 'Pink Guava Segments',
      textureName: 'Guava Texture',
      description: 'Three sweet, crescent-shaped pink guava slices side-by-side.',
      howItCovers: 'Juicy, ruby-pink pulp slabs nested in light-green rinds are placed on the 1x3 line, revealing tiny golden seeds.',
      funFact: 'Guavas contain about four times more vitamin C than oranges, making them absolute immunity powerhouses!',
      emoji: '🍈'
    }
  ],
  'Trio Vertical': [
    {
      id: 'starfruit_slices_v',
      name: 'Starfruit Slices',
      textureName: 'Starfruit Texture',
      description: 'Three crisp, star-shaped yellow carambola slices stacked in a column.',
      howItCovers: 'Perfect five-pointed golden stars are laid flat on the 3x1 strip. The translucent yellow flesh with green edges catches the light beautifully.',
      funFact: 'Starfruit is entirely edible, including the skin, and gets its name from the star-like cross-section when sliced!',
      emoji: '⭐'
    },
    {
      id: 'guava_segments_v',
      name: 'Pink Guava Segments',
      textureName: 'Guava Texture',
      description: 'Three sweet, crescent-shaped pink guava slices stacked in a column.',
      howItCovers: 'Juicy, ruby-pink pulp slabs nested in light-green rinds are placed on the 3x1 line, revealing tiny golden seeds.',
      funFact: 'Guavas contain about four times more vitamin C than oranges, making them absolute immunity powerhouses!',
      emoji: '🍈'
    }
  ],
  'Small Corner L': [
    {
      id: 'passionfruit_l',
      name: 'Passionfruit Halves',
      textureName: 'Purple/Gold Texture',
      description: 'Three rich, hollowed purple passionfruit shells filled with gelatinous golden seeds.',
      howItCovers: 'Three circular passionfruit cups fit into the corner blocks. The dark plum-colored rinds contrast with the glowing orange pulp.',
      funFact: 'The name passion fruit was given by Spanish missionaries in Brazil who saw symbols of the Passion of Christ in its exotic flowers.',
      emoji: '🟣'
    },
    {
      id: 'papaya_boats_l',
      name: 'Papaya Boats',
      textureName: 'Orange Papaya Texture',
      description: 'Three crescent-carved papaya boats nestled together along the corner.',
      howItCovers: 'Beautiful orange-fleshed papaya wedges, filled with tiny dark, shiny seeds, line the corner block perfectly.',
      funFact: 'Papaya seeds are edible and have a sharp, peppery flavor, sometimes used as a substitute for black peppercorns!',
      emoji: '🥭'
    }
  ],
  'Small Corner R': [
    {
      id: 'passionfruit_r',
      name: 'Passionfruit Halves',
      textureName: 'Purple/Gold Texture',
      description: 'Three rich, hollowed purple passionfruit shells filled with gelatinous golden seeds.',
      howItCovers: 'Three circular passionfruit cups fit into the corner blocks. The dark plum-colored rinds contrast with the glowing orange pulp.',
      funFact: 'The name passion fruit was given by Spanish missionaries in Brazil who saw symbols of the Passion of Christ in its exotic flowers.',
      emoji: '🟣'
    },
    {
      id: 'papaya_boats_r',
      name: 'Papaya Boats',
      textureName: 'Orange Papaya Texture',
      description: 'Three crescent-carved papaya boats nestled together along the corner.',
      howItCovers: 'Beautiful orange-fleshed papaya wedges, filled with tiny dark, shiny seeds, line the corner block perfectly.',
      funFact: 'Papaya seeds are edible and have a sharp, peppery flavor, sometimes used as a substitute for black peppercorns!',
      emoji: '🥭'
    }
  ],
  'Pentomino Line H': [
    {
      id: 'pomegranate_arils_h',
      name: 'Pomegranate Aril Skewer',
      textureName: 'Ruby Red Texture',
      description: 'Five translucent, deep crimson pomegranate seeds (arils) stacked in a perfect horizontal row.',
      howItCovers: 'Five jewel-like, angular red seeds are aligned along the 1x5 layout, each glowing with an internal ruby light.',
      funFact: 'A single pomegranate can contain up to 1,400 individual arils, and each one is bursting with tart juice!',
      emoji: '🔴'
    },
    {
      id: 'sugarcane_joint_h',
      name: 'Sugarcane Joint Cane',
      textureName: 'Sugarcane Texture',
      description: 'A five-segmented green sugarcane stalk, carved cleanly to cover the long 1x5 line.',
      howItCovers: 'The stalk sections are joined at the nodes, forming a segmented, bamboo-like green-and-yellow horizontal column.',
      funFact: 'Sugarcane is actually a giant grass, and is responsible for over 70% of the world sugar production!',
      emoji: '🎋'
    }
  ],
  'Pentomino Line V': [
    {
      id: 'pomegranate_arils_v',
      name: 'Pomegranate Aril Skewer',
      textureName: 'Ruby Red Texture',
      description: 'Five translucent, deep crimson pomegranate seeds (arils) stacked in a perfect vertical row.',
      howItCovers: 'Five jewel-like, angular red seeds are aligned along the 5x1 layout, each glowing with an internal ruby light.',
      funFact: 'A single pomegranate can contain up to 1,400 individual arils, and each one is bursting with tart juice!',
      emoji: '🔴'
    },
    {
      id: 'sugarcane_joint_v',
      name: 'Sugarcane Joint Cane',
      textureName: 'Sugarcane Texture',
      description: 'A five-segmented green sugarcane stalk, carved cleanly to cover the long 5x1 line.',
      howItCovers: 'The stalk sections are joined at the nodes, forming a segmented, bamboo-like green-and-yellow vertical column.',
      funFact: 'Sugarcane is actually a giant grass, and is responsible for over 70% of the world sugar production!',
      emoji: '🎋'
    }
  ],
  'Big L-Corner 3x3': [
    {
      id: 'cantaloupe_slices',
      name: 'Cantaloupe Melon Slices',
      textureName: 'Melon Texture',
      description: 'Five thick, crescent-shaped orange cantaloupe slices arranged in a monumental corner curve.',
      howItCovers: 'The juicy orange melon flesh is lined by a textured, webbed green-beige rind, curving majestically around the 3x3 boundary.',
      funFact: 'Cantaloupes are named after Cantalupo in Sabina, Italy, a papal county seat where seeds from Persia were planted.',
      emoji: '🍈'
    },
    {
      id: 'coconut_shells',
      name: 'Coconut Shell Halves',
      textureName: 'Coconut Texture',
      description: 'Five cracked coconut halves with snowy-white meat inside hairy brown outer shells.',
      howItCovers: 'The five blocks of the L-shape are covered with circular white coconut cups, presenting a high-contrast nutty border.',
      funFact: 'Coconuts are extremely buoyant and can float across entire oceans for months before germinating on a new beach!',
      emoji: '🥥'
    }
  ],
  'Pentomino Cross': [
    {
      id: 'star_apple',
      name: 'Star Apple Cross-cut (Caimito)',
      textureName: 'Star Apple Texture',
      description: 'Five slices of exotic purple star apple, revealing their beautiful star-shaped core pulp.',
      howItCovers: 'A central slice with a perfect star core, surrounded by four radiating purple pulp segments in a cross formation.',
      funFact: 'Star apples are native to the West Indies and when cut in half, the seeds radiate in an elegant 8-point star pattern!',
      emoji: '🌟'
    },
    {
      id: 'jackfruit_pods',
      name: 'Jackfruit Pod Cluster',
      textureName: 'Jackfruit Texture',
      description: 'Five golden, plump jackfruit pods arranged tightly in a cross shape.',
      howItCovers: 'Fleshy, bell-shaped golden jackfruit pods cover each of the 5 cross-blocks, looking rich, glossy, and tropical.',
      funFact: 'Jackfruit is the largest tree-borne fruit in the world, capable of reaching weights of up to 120 pounds!',
      emoji: '🍍'
    }
  ]
};

export const DEFAULT_SKINS: Record<string, string> = {
  'Single Dot': 'wild_raspberry',
  'Domino Horizontal': 'apricot_slabs',
  'Domino Vertical': 'plum_halves',
  'Trio Horizontal': 'starfruit_slices_h',
  'Trio Vertical': 'starfruit_slices_v',
  'Small Corner L': 'passionfruit_l',
  'Small Corner R': 'passionfruit_r',
  'Tetromino Line H': 'blueberry_skewer',
  'Tetromino Line V': 'blueberry_skewer_v',
  'Tetromino Square': 'lemon_wheel',
  'Tetromino T': 'plum_slices',
  'Tetromino L-Left': 'clementine_segments',
  'Tetromino L-Right': 'clementine_segments_r',
  'Tetromino Z': 'kiwi_crosscut',
  'Tetromino S': 'strawberry',
  'Pentomino Line H': 'pomegranate_arils_h',
  'Pentomino Line V': 'pomegranate_arils_v',
  'Big L-Corner 3x3': 'cantaloupe_slices',
  'Pentomino Cross': 'star_apple',
};

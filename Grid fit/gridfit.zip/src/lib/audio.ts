/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Sound Synthesizer using Web Audio API for GridFit
// Programmatic audio allows for zero asset download dependencies and rich dynamic audio.

class AudioEngine {
  private ctx: AudioContext | null = null;
  private musicInterval: any = null;
  private currentMusicNodes: AudioNode[] = [];
  public isMusicMuted: boolean = false;
  public isSfxMuted: boolean = false;
  private isMusicPlaying: boolean = false;
  private bgAudio: HTMLAudioElement | null = null;
  public musicType: 'synth' | 'mp3' = 'synth';

  constructor() {
    // Lazy initialisation to prevent browser autoplay warnings
  }

  private init() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public toggleMusic(mute: boolean) {
    this.isMusicMuted = mute;
    if (mute) {
      this.stopMusic();
    } else {
      this.startMusic();
    }
  }

  public toggleSfx(mute: boolean) {
    this.isSfxMuted = mute;
  }

  // SFX: Tap/Click
  public playClick() {
    if (this.isSfxMuted) return;
    this.init();
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(600, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(300, this.ctx.currentTime + 0.05);

    gain.gain.setValueAtTime(0.05, this.ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.001, this.ctx.currentTime + 0.05);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.05);
  }

  // SFX: Satisfying block snap ("thwack")
  public playThwack() {
    if (this.isSfxMuted) return;
    this.init();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;

    // Bass thud
    const osc1 = this.ctx.createOscillator();
    const gain1 = this.ctx.createGain();
    osc1.type = 'triangle';
    osc1.frequency.setValueAtTime(150, now);
    osc1.frequency.exponentialRampToValueAtTime(45, now + 0.15);
    gain1.gain.setValueAtTime(0.65, now); // Louder: was 0.25
    gain1.gain.linearRampToValueAtTime(0.001, now + 0.15);
    osc1.connect(gain1);
    gain1.connect(this.ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.16);

    // Click snap transient
    const osc2 = this.ctx.createOscillator();
    const gain2 = this.ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(800, now);
    osc2.frequency.exponentialRampToValueAtTime(200, now + 0.04);
    gain2.gain.setValueAtTime(0.35, now); // Louder: was 0.12
    gain2.gain.linearRampToValueAtTime(0.001, now + 0.04);
    osc2.connect(gain2);
    gain2.connect(this.ctx.destination);
    osc2.start(now);
    osc2.stop(now + 0.05);
  }

  // SFX: Ascending melodic chimes for row/column clears
  public playLineClear(combo: number = 1) {
    if (this.isSfxMuted) return;
    this.init();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    // Scales: major scale notes
    // Base scale C, E, G, C, E, G...
    const baseFreqs = [261.63, 329.63, 392.00, 523.25, 659.25, 783.99, 1046.50];
    const pitchShiftFactor = combo > 1 ? 1.5 : 1.0;

    const notesToPlay = Math.min(3 + combo, 6);
    
    for (let i = 0; i < notesToPlay; i++) {
      const triggerTime = now + i * 0.08;
      const freq = baseFreqs[i % baseFreqs.length] * pitchShiftFactor;

      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, triggerTime);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(freq * 2, triggerTime);

      gain.gain.setValueAtTime(0, triggerTime);
      gain.gain.linearRampToValueAtTime(0.15, triggerTime + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.001, triggerTime + 0.4);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(triggerTime);
      osc.stop(triggerTime + 0.45);
    }
  }

  // SFX: Play dynamic sound on revive
  public playRevive() {
    if (this.isSfxMuted) return;
    this.init();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    // Sparkling scale of upwards chimes
    for (let i = 0; i < 12; i++) {
      const triggerTime = now + i * 0.04;
      const freq = 300 + i * 120 + Math.random() * 50;

      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, triggerTime);

      gain.gain.setValueAtTime(0, triggerTime);
      gain.gain.linearRampToValueAtTime(0.08, triggerTime + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.001, triggerTime + 0.2);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(triggerTime);
      osc.stop(triggerTime + 0.22);
    }
  }

  // SFX: Play game over sound
  public playGameOver() {
    if (this.isSfxMuted) return;
    this.init();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const baseFreqs = [392.00, 349.23, 311.13, 261.63]; // G4, F4, Eb4, C4 (sad minor descend)

    for (let i = 0; i < baseFreqs.length; i++) {
      const triggerTime = now + i * 0.15;
      const freq = baseFreqs[i];

      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, triggerTime);

      gain.gain.setValueAtTime(0.12, triggerTime);
      gain.gain.linearRampToValueAtTime(0.001, triggerTime + 0.35);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(triggerTime);
      osc.stop(triggerTime + 0.4);
    }
  }

  // PROCEDURAL WEB AUDIO SYNTHESIZED SONG (Infinite, dynamic relaxation)
  private playProceduralSynth() {
    if (!this.ctx || this.isMusicMuted || !this.isMusicPlaying) return;
    const now = this.ctx.currentTime;

    // A beautiful 4-chord progression running in a loop (4 seconds per chord)
    const chords = [
      [130.81, 196.00, 246.94, 293.66, 329.63], // Cmaj9 (C3, G3, B3, D4, E4)
      [110.00, 164.81, 196.00, 246.94, 261.63], // Am9 (A2, E3, G3, B3, C4)
      [87.31, 130.81, 174.61, 220.00, 329.63],  // Fmaj7 (F2, C3, F3, A3, E4)
      [98.00, 146.83, 196.00, 246.94, 329.63]   // G6 (G2, D3, G3, B3, E4)
    ];

    // Hand-crafted beautiful pentatonic melody loop (16 beats, 500ms per beat)
    const melody = [
      329.63, 0, 392.00, 440.00, 523.25, 0, 440.00, 392.00,
      329.63, 293.66, 0, 329.63, 392.00, 0, 293.66, 261.63
    ];

    let chordIndex = 0;
    let melodyIndex = 0;

    // Clean up old interval if any
    if (this.musicInterval) {
      clearInterval(this.musicInterval);
    }

    const lowpass = this.ctx.createBiquadFilter();
    lowpass.type = 'lowpass';
    lowpass.frequency.setValueAtTime(450, now);
    lowpass.connect(this.ctx.destination);
    this.currentMusicNodes.push(lowpass);

    const tick = () => {
      if (!this.ctx || this.isMusicMuted || !this.isMusicPlaying) return;
      const t = this.ctx.currentTime;

      // 1. Play chords every 8 ticks (every 4 seconds)
      if (melodyIndex % 8 === 0) {
        const chordNotes = chords[chordIndex];
        chordNotes.forEach((freq, idx) => {
          if (!this.ctx) return;
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();

          osc.type = idx === 0 ? 'sine' : 'triangle'; // sine bass, triangle keys
          osc.frequency.setValueAtTime(freq, t);

          // Relaxing low volumes
          const vol = idx === 0 ? 0.04 : 0.015;
          gain.gain.setValueAtTime(0, t);
          gain.gain.linearRampToValueAtTime(vol, t + 1.2); // soft fade-in attack
          gain.gain.setValueAtTime(vol, t + 3.4);
          gain.gain.exponentialRampToValueAtTime(0.0001, t + 3.95); // gentle decay

          osc.connect(gain);
          gain.connect(lowpass);
          osc.start(t);
          osc.stop(t + 4.0);

          this.currentMusicNodes.push(osc);
        });
        chordIndex = (chordIndex + 1) % chords.length;
      }

      // 2. Play beautiful melody notes every tick (0.5 seconds)
      const melFreq = melody[melodyIndex];
      if (melFreq > 0) {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'sine'; // pure glassy sine bell plucks
        osc.frequency.setValueAtTime(melFreq, t);

        gain.gain.setValueAtTime(0, t);
        gain.gain.linearRampToValueAtTime(0.016, t + 0.04); // quick pluck attack
        gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.42); // long decay

        osc.connect(gain);
        gain.connect(lowpass);
        osc.start(t);
        osc.stop(t + 0.5);

        this.currentMusicNodes.push(osc);
      }

      melodyIndex = (melodyIndex + 1) % melody.length;
    };

    // Trigger immediately and schedule repeat
    tick();
    this.musicInterval = setInterval(tick, 500);
  }

  // START DUAL-MODE BACKGROUND MUSIC
  public startMusic() {
    if (this.isMusicMuted) return;
    this.isMusicPlaying = true;

    if (this.musicType === 'synth') {
      this.init();
      this.playProceduralSynth();
    } else {
      if (!this.bgAudio) {
        this.bgAudio = new Audio();
        this.bgAudio.loop = true;
        this.bgAudio.volume = 0.25;

        this.bgAudio.src = "https://cdn1.suno.ai/6e7ef541-13ff-406d-af44-b40acbc7fdfe.mp3";

        this.bgAudio.onerror = () => {
          if (this.bgAudio && this.bgAudio.src !== "https://audiocdn.suno.ai/6e7ef541-13ff-406d-af44-b40acbc7fdfe.mp3") {
            console.warn("Falling back to backup audio CDN...");
            this.bgAudio.src = "https://audiocdn.suno.ai/6e7ef541-13ff-406d-af44-b40acbc7fdfe.mp3";
            if (this.isMusicPlaying && !this.isMusicMuted) {
              this.bgAudio.play().catch(err => console.error("Audio playback error on fallback:", err));
            }
          }
        };
      }

      this.bgAudio.play().catch(err => {
        console.warn("Autoplay or audio load prevented by browser:", err);
      });
    }
  }

  // STOP MUSIC & CLEAN UP ALL NODES/INTERVALS
  public stopMusic() {
    this.isMusicPlaying = false;
    if (this.bgAudio) {
      this.bgAudio.pause();
    }
    if (this.musicInterval) {
      clearInterval(this.musicInterval);
      this.musicInterval = null;
    }
    this.currentMusicNodes.forEach(node => {
      try {
        (node as any).stop();
      } catch(e) {}
      try {
        (node as any).disconnect();
      } catch(e) {}
    });
    this.currentMusicNodes = [];
  }

  // SET AND CHANGE MUSIC TYPE ON THE FLY
  public setMusicType(type: 'synth' | 'mp3') {
    this.musicType = type;
    if (this.isMusicPlaying && !this.isMusicMuted) {
      this.stopMusic();
      this.startMusic();
    }
  }
}

export const sfx = new AudioEngine();

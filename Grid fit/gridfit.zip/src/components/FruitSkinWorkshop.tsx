/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Info, Sparkles, ChevronLeft, ChevronRight, Check } from 'lucide-react';
import { SHAPE_TEMPLATES } from '../lib/shapes';
import { FRUIT_SKINS, DEFAULT_SKINS, FruitSkinConfig } from '../lib/fruitSkins';
import { FruitCell } from './FruitCell';
import { sfx } from '../lib/audio';

interface FruitSkinWorkshopProps {
  isFruitTheme: boolean;
  onToggleFruitTheme: () => void;
  selectedSkins: Record<string, string>;
  onSelectSkin: (templateName: string, skinId: string) => void;
}

export const FruitSkinWorkshop: React.FC<FruitSkinWorkshopProps> = ({
  isFruitTheme,
  onToggleFruitTheme,
  selectedSkins,
  onSelectSkin,
}) => {
  // Let's keep track of the currently selected template index for editing skins
  const [selectedTemplateIndex, setSelectedTemplateIndex] = useState(0);

  // Filter out duplicate shape templates by name to avoid confusion (some templates might share the same shape name but different layout, e.g. H/V)
  const uniqueTemplates = SHAPE_TEMPLATES.reduce((acc, current) => {
    const x = acc.find(item => item.name === current.name);
    if (!x) {
      return acc.concat([current]);
    } else {
      return acc;
    }
  }, [] as typeof SHAPE_TEMPLATES);

  const activeTemplate = uniqueTemplates[selectedTemplateIndex];
  const templateSkins = FRUIT_SKINS[activeTemplate?.name] || [];
  const activeSkinId = selectedSkins[activeTemplate?.name] || DEFAULT_SKINS[activeTemplate?.name];
  const activeSkin = templateSkins.find(s => s.id === activeSkinId) || templateSkins[0];

  const handlePrevTemplate = () => {
    sfx.playClick();
    setSelectedTemplateIndex(prev => (prev === 0 ? uniqueTemplates.length - 1 : prev - 1));
  };

  const handleNextTemplate = () => {
    sfx.playClick();
    setSelectedTemplateIndex(prev => (prev === uniqueTemplates.length - 1 ? 0 : prev + 1));
  };

  const handleSelectSkinCard = (skin: FruitSkinConfig) => {
    sfx.playThwack();
    onSelectSkin(activeTemplate.name, skin.id);
  };

  return (
    <div 
      id="fruit-skin-workshop-card"
      className="w-full bg-slate-900/80 border border-white/10 rounded-2xl p-4 flex flex-col gap-4 shadow-xl text-white overflow-hidden relative"
    >
      {/* Background glow */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-500/10 blur-3xl pointer-events-none rounded-full" />
      <div className="absolute bottom-0 left-0 w-32 h-32 bg-rose-500/10 blur-3xl pointer-events-none rounded-full" />

      {/* Header section with toggle */}
      <div className="flex items-center justify-between border-b border-white/5 pb-2.5">
        <div className="flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-yellow-400 animate-spin-slow" />
          <h3 className="font-bold font-display text-sm uppercase tracking-wider text-yellow-100">
            Fruit Skin Workshop
          </h3>
        </div>

        <button
          onClick={() => { sfx.playClick(); onToggleFruitTheme(); }}
          className={`px-3 py-1 rounded-full text-[10px] font-mono font-black tracking-widest uppercase transition-all duration-300 border ${
            isFruitTheme
              ? 'bg-gradient-to-r from-yellow-500 to-amber-500 text-slate-950 border-yellow-400 font-extrabold shadow-md shadow-yellow-500/25'
              : 'bg-slate-950/40 text-slate-400 border-white/10 hover:text-white hover:border-white/20'
          }`}
        >
          {isFruitTheme ? '🍉 SKINS ON' : '⚫ SKINS OFF'}
        </button>
      </div>

      {/* Block Shape Carousel Switcher */}
      <div className="flex items-center justify-between bg-slate-950/40 rounded-xl p-2 border border-white/5">
        <button
          onClick={handlePrevTemplate}
          className="p-1 rounded-lg hover:bg-white/10 active:scale-95 transition text-slate-400 hover:text-white"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <div className="flex flex-col items-center justify-center text-center">
          <span className="text-[10px] font-mono tracking-wider text-slate-400 uppercase font-bold">
            Selected Block
          </span>
          <span className="text-xs font-semibold text-white tracking-wide mt-0.5">
            {activeTemplate?.name}
          </span>
        </div>

        <button
          onClick={handleNextTemplate}
          className="p-1 rounded-lg hover:bg-white/10 active:scale-95 transition text-slate-400 hover:text-white"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Interactive Render Canvas Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        {/* Render Canvas Column */}
        <div className="md:col-span-5 flex flex-col items-center justify-center bg-slate-950/65 rounded-xl p-4 border border-white/5 min-h-[160px] relative">
          <span className="absolute top-2 left-3 text-[8px] font-mono uppercase text-slate-500 tracking-widest">
            Interactive Render Canvas
          </span>

          {activeTemplate && (
            <div
              className="grid gap-[3px] border border-white/10 p-3 bg-slate-900/60 rounded-xl shadow-lg mt-3"
              style={{
                gridTemplateColumns: `repeat(${activeTemplate.width}, minmax(0, 1fr))`,
              }}
            >
              {Array.from({ length: activeTemplate.height }).map((_, r) => {
                return Array.from({ length: activeTemplate.width }).map((_, c) => {
                  const hasBlock = activeTemplate.blocks.some((b) => b.row === r && b.col === c);
                  const sizeStyle = { width: '42px', height: '42px' };

                  if (!hasBlock) {
                    return <div key={`${r}-${c}`} style={sizeStyle} className="opacity-0" />;
                  }

                  return (
                    <div
                      key={`${r}-${c}`}
                      className="rounded-lg shadow-md relative overflow-hidden"
                      style={sizeStyle}
                    >
                      <FruitCell
                        skinId={activeSkin?.id || ''}
                        row={r}
                        col={c}
                        width={activeTemplate.width}
                        height={activeTemplate.height}
                        color={activeTemplate.color}
                        cellSize={42}
                      />
                    </div>
                  );
                });
              })}
            </div>
          )}

          {activeSkin && (
            <div className="mt-3.5 px-2.5 py-1 rounded-full bg-yellow-500/10 border border-yellow-500/20 text-[10px] text-yellow-300 font-semibold font-mono tracking-wide flex items-center gap-1">
              <span>{activeSkin.emoji}</span>
              <span>{activeSkin.name} Skin applied</span>
            </div>
          )}
        </div>

        {/* Suggested Face Cover Details Column */}
        <div className="md:col-span-7 flex flex-col gap-2 justify-between">
          {activeSkin ? (
            <div className="flex flex-col gap-2.5">
              <div>
                <span className="text-[9px] font-mono tracking-widest text-slate-400 uppercase font-black block">
                  Suggested Face Cover
                </span>
                <h4 className="text-sm font-black text-yellow-100 font-display mt-0.5">
                  {activeSkin.name}
                </h4>
                <p className="text-[11px] text-slate-300 leading-normal font-sans mt-1">
                  {activeSkin.description}
                </p>
              </div>

              <div className="text-[11px] text-slate-300 leading-normal">
                <span className="font-bold text-slate-400 block mb-0.5">How it covers the Face:</span>
                <p>{activeSkin.howItCovers}</p>
              </div>

              {/* Fun Fact Container */}
              <div className="bg-sky-500/10 border border-sky-500/30 rounded-xl p-2.5 text-[11px] text-sky-200 flex items-start gap-2 leading-normal">
                <Info className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-sky-300 block mb-0.5">Fun Fact:</span>
                  <p>{activeSkin.funFact}</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-slate-400 text-xs text-center py-10">
              No skins configured for this block template.
            </div>
          )}
        </div>
      </div>

      {/* Slices Selector Row */}
      {templateSkins.length > 0 && (
        <div className="flex flex-col gap-2 border-t border-white/5 pt-3">
          <span className="text-[10px] font-mono tracking-wider text-slate-400 uppercase font-bold">
            Select Covering Slices for {activeTemplate?.name}:
          </span>

          <div className="grid grid-cols-2 xs:grid-cols-3 gap-2.5">
            {templateSkins.map((skin) => {
              const isActive = skin.id === activeSkinId;
              return (
                <button
                  key={skin.id}
                  onClick={() => handleSelectSkinCard(skin)}
                  className={`p-2.5 rounded-xl border text-left flex items-center gap-2.5 transition-all duration-300 select-none cursor-pointer relative overflow-hidden group
                    ${isActive
                      ? 'bg-gradient-to-r from-yellow-500/20 to-amber-500/25 border-yellow-400 text-white shadow-lg'
                      : 'bg-slate-950/40 border-white/10 text-slate-300 hover:bg-slate-950/60 hover:border-white/20 hover:text-white'
                    }`}
                >
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 text-lg transition-all duration-300 bg-slate-900 border
                    ${isActive ? 'border-yellow-400 bg-yellow-400/20 scale-105' : 'border-white/5 group-hover:scale-105'}`}>
                    {skin.emoji}
                  </div>

                  <div className="flex flex-col overflow-hidden leading-tight">
                    <span className="text-[11px] font-bold tracking-wide truncate">
                      {skin.name.split(' (')[0]}
                    </span>
                    <span className="text-[9px] text-slate-400 font-mono mt-0.5 truncate uppercase">
                      {skin.textureName}
                    </span>
                  </div>

                  {isActive && (
                    <div className="absolute right-1.5 top-1.5 w-3.5 h-3.5 rounded-full bg-yellow-400 flex items-center justify-center">
                      <Check className="w-2.5 h-2.5 text-slate-950 stroke-[3.5]" />
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

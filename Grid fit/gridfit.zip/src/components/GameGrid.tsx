/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { CellCoordinate, ShapeTemplate } from '../types';
import { getFruitForColor } from '../lib/shapes';
import { DEFAULT_SKINS } from '../lib/fruitSkins';
import { FruitCell } from './FruitCell';

interface GameGridProps {
  grid: (string | null)[][]; // 10 rows, 8 columns
  draggedShape: ShapeTemplate | null;
  hoveredCell: CellCoordinate | null;
  clearingCells: Set<string>; // Set of "row,col" keys that are currently exploding/clearing
  selectedDockShape: ShapeTemplate | null;
  isFruitTheme: boolean;
  selectedSkins: Record<string, string>;
  onCellClick: (row: number, col: number) => void;
}

export const GameGrid: React.FC<GameGridProps> = ({
  grid,
  draggedShape,
  hoveredCell,
  clearingCells,
  selectedDockShape,
  isFruitTheme,
  selectedSkins,
  onCellClick,
}) => {
  const rows = 10;
  const cols = 8;

  // Check if a cell is part of the current preview of the dragged/selected shape
  const getPreviewStatus = (row: number, col: number) => {
    // 1. Dragged shape preview
    if (draggedShape && hoveredCell) {
      const block = draggedShape.blocks.find(
        (b) => hoveredCell.row + b.row === row && hoveredCell.col + b.col === col
      );
      if (block) {
        return { isPreview: true, template: draggedShape, localRow: block.row, localCol: block.col };
      }
    }
    return { isPreview: false, template: null, localRow: 0, localCol: 0 };
  };

  return (
    <div 
      id="gridfit-board-container"
      className="relative w-full max-w-[340px] xs:max-w-[380px] sm:max-w-[420px] mx-auto p-3 sm:p-4 rounded-2xl glass-panel shadow-3xl border border-white/10"
    >
      {/* 8x10 Grid Board */}
      <div 
        id="gridfit-grid-cells"
        className="grid grid-cols-8 gap-[5px] sm:gap-[7px] aspect-[8/10] w-full"
      >
        {Array.from({ length: rows }).map((_, r) => {
          return Array.from({ length: cols }).map((_, c) => {
            const cellValueRaw = grid[r][c];
            const hasDelimiter = cellValueRaw && cellValueRaw.includes(':');
            const cellValue = hasDelimiter ? cellValueRaw.split(':')[0] : cellValueRaw;
            const templateName = hasDelimiter ? cellValueRaw.split(':')[1] : '';
            const localRow = hasDelimiter ? parseInt(cellValueRaw.split(':')[2], 10) : 0;
            const localCol = hasDelimiter ? parseInt(cellValueRaw.split(':')[3], 10) : 0;

            const isClearing = clearingCells.has(`${r},${c}`);
            const { isPreview, template, localRow: previewRow, localCol: previewCol } = getPreviewStatus(r, c);

            // Styling variables
            let cellStyle: React.CSSProperties = {};
            let cellClasses = "relative aspect-square rounded-[6px] sm:rounded-[8px] transition-all duration-150 cursor-pointer select-none overflow-hidden ";

            if (isClearing) {
              // Clearing flash style
              cellClasses += "flash-clear z-20 scale-95 border-2 border-white";
              cellStyle = { backgroundColor: '#ffffff' };
            } else if (cellValue) {
              // Occupied block
              cellClasses += "block-glow border-t border-white/20 shadow-lg scale-100 z-10 hover:brightness-110";
              cellStyle = { 
                backgroundColor: cellValue,
                borderColor: 'rgba(255, 255, 255, 0.25)',
                ['--glow-color' as any]: `${cellValue}50`
              };
            } else if (isPreview && template) {
              // Snapping Preview - Solid high-contrast glowing indicator
              cellClasses += "border-2 border-solid z-20 scale-[0.98] shadow-lg shadow-inner";
              cellStyle = {
                backgroundColor: `${template.color}65`, // brighter semi-translucent fill
                borderColor: '#ffffff', // bright white solid border
                boxShadow: `0 0 12px ${template.color}a0, inset 0 0 6px rgba(255, 255, 255, 0.4)` // beautiful outer and inner glow
              };
            } else {
              // Empty Cell
              cellClasses += "bg-slate-950/45 border border-slate-900/30 hover:bg-slate-900/40";
              cellStyle = {
                boxShadow: 'inset 0 2px 4px rgba(0, 0, 0, 0.25)'
              };
            }

            // Get skinId if applicable
            const activeSkinId = isFruitTheme && templateName ? (selectedSkins[templateName] || DEFAULT_SKINS[templateName]) : '';
            const previewSkinId = isFruitTheme && template ? (selectedSkins[template.name] || DEFAULT_SKINS[template.name]) : '';

            return (
              <div
                key={`${r}-${c}`}
                id={`grid-cell-${r}-${c}`}
                className={cellClasses}
                style={cellStyle}
                onClick={() => onCellClick(r, c)}
                onTouchEnd={() => {
                  // Enable quick click/tap on cell without interference
                  if (!draggedShape) {
                    onCellClick(r, c);
                  }
                }}
              >
                {/* 1. Custom Fruit Cell representation for occupied cells */}
                {cellValue && !isClearing && isFruitTheme && activeSkinId && (
                  <FruitCell
                    skinId={activeSkinId}
                    row={localRow}
                    col={localCol}
                    width={0}
                    height={0}
                    color={cellValue}
                  />
                )}

                {/* Legacy backup text symbol if no activeSkinId fits */}
                {cellValue && !isClearing && isFruitTheme && !activeSkinId && (
                  <div className="absolute inset-0 flex items-center justify-center text-[15px] xs:text-[17px] sm:text-[19px] select-none leading-none z-10 animate-pulse duration-1000">
                    {getFruitForColor(cellValue).emoji}
                  </div>
                )}

                {/* 2. Custom Fruit Cell representation for preview cells */}
                {isPreview && template && isFruitTheme && previewSkinId && (
                  <div className="absolute inset-0 opacity-60">
                    <FruitCell
                      skinId={previewSkinId}
                      row={previewRow}
                      col={previewCol}
                      width={template.width}
                      height={template.height}
                      color={template.color}
                    />
                  </div>
                )}

                {/* Legacy preview fallback */}
                {isPreview && template && isFruitTheme && !previewSkinId && (
                  <div className="absolute inset-0 flex items-center justify-center text-[15px] xs:text-[17px] sm:text-[19px] select-none leading-none z-10 opacity-70">
                    {getFruitForColor(template.color).emoji}
                  </div>
                )}

                {/* Shiny gloss overlay on normal filled blocks */}
                {cellValue && !isClearing && !isFruitTheme && (
                  <div className="absolute inset-x-0 top-0 h-[40%] bg-gradient-to-b from-white/25 to-transparent rounded-t-[5px]" />
                )}
              </div>
            );
          });
        })}
      </div>
    </div>
  );
};

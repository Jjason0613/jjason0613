/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useEffect, useImperativeHandle, forwardRef } from 'react';
import { Particle, FloatingText } from '../types';

export interface JuiceCanvasRef {
  spawnParticles: (row: number, col: number, color: string, cellWidth: number, cellHeight: number) => void;
  spawnText: (text: string, x: number, y: number, color?: string, isBig?: boolean) => void;
  triggerScreenShake: () => void;
}

interface JuiceCanvasProps {
  onShakeEnd: () => void;
}

export const JuiceCanvas = forwardRef<JuiceCanvasRef, JuiceCanvasProps>(({ onShakeEnd }, ref) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const particlesRef = useRef<Particle[]>([]);
  const textsRef = useRef<FloatingText[]>([]);
  const animationFrameIdRef = useRef<number | null>(null);

  // Expose triggers to parent
  useImperativeHandle(ref, () => ({
    spawnParticles(row: number, col: number, color: string, cellWidth: number, cellHeight: number) {
      if (!canvasRef.current) return;
      const canvas = canvasRef.current;
      
      // Calculate pixel coordinates for the center of the cell
      const x = col * cellWidth + cellWidth / 2;
      const y = row * cellHeight + cellHeight / 2;

      // Spawn 10-15 particles
      const count = 12 + Math.floor(Math.random() * 6);
      for (let i = 0; i < count; i++) {
        const angle = Math.random() * Math.PI * 2;
        // Exploding speed outward
        const speed = 2 + Math.random() * 6;
        const vx = Math.cos(angle) * speed;
        const vy = Math.sin(angle) * speed - (1 + Math.random() * 2); // bias slightly upwards

        particlesRef.current.push({
          id: Math.random().toString(),
          x,
          y,
          vx,
          vy,
          color,
          alpha: 1,
          size: 6 + Math.random() * 8,
          rotation: Math.random() * Math.PI * 2,
          vRotation: (Math.random() - 0.5) * 0.2,
        });
      }
    },
    spawnText(text: string, x: number, y: number, color: string = '#ffffff', isBig: boolean = false) {
      textsRef.current.push({
        id: Math.random().toString(),
        text,
        x,
        y,
        alpha: 1,
        scale: isBig ? 1.4 : 1.0,
      });
    },
    triggerScreenShake() {
      // Screen shake is handled by adding/removing CSS class on the container in App.tsx
    }
  }));

  // Resize canvas to match its display size
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const resizeCanvas = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * window.devicePixelRatio;
      canvas.height = rect.height * window.devicePixelRatio;
      
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
      }
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Animation Loop
    const render = () => {
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const rect = canvas.getBoundingClientRect();
      ctx.clearRect(0, 0, rect.width, rect.height);

      // --- Update & Draw Particles ---
      const particles = particlesRef.current;
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        
        // Physics
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.25; // gravity
        p.vx *= 0.98; // horizontal friction
        p.alpha -= 0.022; // fade out
        p.rotation += p.vRotation;
        p.size *= 0.96; // shrink

        if (p.alpha <= 0 || p.size < 0.5) {
          particles.splice(i, 1);
          continue;
        }

        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rotation);
        
        // Glowing drop shadow path
        ctx.shadowBlur = 10;
        ctx.shadowColor = p.color;
        
        ctx.fillStyle = p.color;
        // Draw a satisfying rectangular brick fragment
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
        ctx.restore();
      }

      // --- Update & Draw Floating Texts ---
      const texts = textsRef.current;
      for (let i = texts.length - 1; i >= 0; i--) {
        const t = texts[i];
        
        // Float upwards, fade out
        t.y -= 1.6;
        t.alpha -= 0.016;
        t.scale = Math.max(0.8, t.scale - 0.004);

        if (t.alpha <= 0) {
          texts.splice(i, 1);
          continue;
        }

        ctx.save();
        ctx.translate(t.x, t.y);
        ctx.scale(t.scale, t.scale);
        
        // Styling for game points display
        ctx.shadowBlur = 8;
        ctx.shadowColor = 'rgba(0, 0, 0, 0.6)';
        
        // Outer stroke
        ctx.font = `bold ${t.scale > 1.1 ? '22px' : '18px'} "Space Grotesk", sans-serif`;
        ctx.textAlign = 'center';
        ctx.strokeStyle = '#020617';
        ctx.lineWidth = 4;
        ctx.strokeText(t.text, 0, 0);

        // Fill color
        const fillGrad = ctx.createLinearGradient(0, -10, 0, 10);
        fillGrad.addColorStop(0, '#ffffff');
        fillGrad.addColorStop(1, '#facc15'); // beautiful yellow glow
        
        ctx.fillStyle = fillGrad;
        ctx.fillText(t.text, 0, 0);
        
        ctx.restore();
      }

      animationFrameIdRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      if (animationFrameIdRef.current) {
        cancelAnimationFrame(animationFrameIdRef.current);
      }
    };
  }, []);

  return (
    <canvas
      id="juice-canvas"
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none z-10"
      style={{ mixBlendMode: 'screen' }}
    />
  );
});

JuiceCanvas.displayName = 'JuiceCanvas';

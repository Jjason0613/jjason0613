/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Trophy, Flame, RotateCcw, Volume2, VolumeX, Music, ShieldCheck, Crown, Apple } from 'lucide-react';

interface ScoreBoardProps {
  score: number;
  highScore: number;
  streak: number;
  streakMultiplier: number;
  isMusicMuted: boolean;
  isSfxMuted: boolean;
  musicType: 'synth' | 'mp3';
  clearBonusLevel: number;
  isFruitTheme: boolean;
  onToggleMusic: () => void;
  onToggleSfx: () => void;
  onRestart: () => void;
  onToggleMusicType: () => void;
  onToggleFruitTheme: () => void;
}

export const ScoreBoard: React.FC<ScoreBoardProps> = ({
  score,
  highScore,
  streak,
  streakMultiplier,
  isMusicMuted,
  isSfxMuted,
  musicType,
  clearBonusLevel,
  isFruitTheme,
  onToggleMusic,
  onToggleSfx,
  onRestart,
  onToggleMusicType,
  onToggleFruitTheme,
}) => {
  return (
    <div 
      id="gridfit-scoreboard-wrapper"
      className="w-full flex flex-col gap-3 relative"
    >
      {/* 1. Title & Actions Bento Card */}
      <div className="w-full p-4 rounded-2xl glass-panel border border-white/10 flex items-center justify-between shadow-xl relative overflow-hidden group hover:border-white/15 transition-all duration-300">
        {/* Soft background light */}
        <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-20 h-20 bg-rose-500/5 rounded-full blur-2xl pointer-events-none" />

        <div className="flex flex-col">
          <h1 
            id="game-logo-title"
            className="text-2xl font-bold font-display tracking-wider bg-gradient-to-r from-indigo-400 via-sky-400 to-emerald-400 bg-clip-text text-transparent filter drop-shadow-sm select-none"
          >
            GridFit
          </h1>
          <button
            onClick={onToggleMusicType}
            className="text-[9px] tracking-widest text-slate-400/80 hover:text-indigo-400 transition cursor-pointer text-left uppercase font-mono mt-0.5 flex items-center gap-1 group/track"
            title="Switch Soundtrack"
          >
            <span>🎵 Track:</span>
            <span className="font-semibold text-indigo-300 border-b border-indigo-500/20 group-hover/track:border-indigo-400 transition-all duration-150">
              {musicType === 'synth' ? 'Dreamy Synth' : 'Suno Cosmic'}
            </span>
          </button>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 z-10">
          {/* Mute Music */}
          <button
            id="toggle-music-btn"
            onClick={onToggleMusic}
            className={`p-2 rounded-lg border transition-all duration-200 hover:scale-105 active:scale-95 cursor-pointer ${
              !isMusicMuted 
                ? 'bg-indigo-500/10 border-indigo-500/30 text-indigo-300 hover:bg-indigo-500/15' 
                : 'bg-slate-900/40 border-white/5 text-slate-500 hover:text-slate-400'
            }`}
            title={isMusicMuted ? "Unmute Music" : "Mute Music"}
          >
            <Music className="w-4 h-4" />
          </button>

          {/* Mute SFX */}
          <button
            id="toggle-sfx-btn"
            onClick={onToggleSfx}
            className={`p-2 rounded-lg border transition-all duration-200 hover:scale-105 active:scale-95 cursor-pointer ${
              !isSfxMuted 
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300 hover:bg-emerald-500/15' 
                : 'bg-slate-900/40 border-white/5 text-slate-500 hover:text-slate-400'
            }`}
            title={isSfxMuted ? "Unmute Sound" : "Mute Sound"}
          >
            {!isSfxMuted ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Fruit / Classic Theme Toggle */}
          <button
            id="toggle-fruit-theme-btn"
            onClick={onToggleFruitTheme}
            className={`p-2 rounded-lg border transition-all duration-200 hover:scale-105 active:scale-95 cursor-pointer ${
              isFruitTheme 
                ? 'bg-amber-500/10 border-amber-500/30 text-amber-300 hover:bg-amber-500/15' 
                : 'bg-slate-900/40 border-white/5 text-slate-500 hover:text-slate-400'
            }`}
            title={isFruitTheme ? "Switch to Classic Glass Blocks" : "Switch to Nano Fruit Salad Mode"}
          >
            <Apple className="w-4 h-4" />
          </button>

          {/* Restart */}
          <button
            id="restart-game-btn"
            onClick={onRestart}
            className="p-2 rounded-lg bg-slate-900/50 border border-white/10 text-slate-300 hover:border-rose-500/30 hover:text-rose-400 hover:bg-rose-500/10 transition-all duration-200 hover:scale-105 active:scale-95 cursor-pointer"
            title="Restart Game"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 2. Scores Grid (Two adjacent Bento Cards) */}
      <div className="grid grid-cols-2 gap-3">
        {/* Current Score Bento Card */}
        <div 
          id="score-block"
          className="bg-slate-900/65 border border-white/10 rounded-2xl p-4 flex flex-col justify-center items-center relative overflow-hidden group hover:border-indigo-500/25 hover:bg-slate-800/30 transition-all duration-300 shadow-md"
        >
          <div className="absolute top-0 inset-x-0 h-[2.5px] bg-gradient-to-r from-indigo-500 to-sky-500 opacity-80" />
          <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400/60">Current Score</span>
          <span className="text-2xl sm:text-3xl font-bold font-mono tracking-tight text-white mt-1 select-none transition-all duration-200 group-hover:scale-105">
            {score}
          </span>
        </div>

        {/* High Score Bento Card */}
        <div 
          id="highscore-block"
          className="bg-slate-900/65 border border-white/10 rounded-2xl p-4 flex flex-col justify-center items-center relative overflow-hidden group hover:border-amber-500/25 hover:bg-slate-800/30 transition-all duration-300 shadow-md"
        >
          <div className="absolute top-0 inset-x-0 h-[2.5px] bg-gradient-to-r from-amber-500 to-yellow-500 opacity-80" />
          <div className="flex items-center gap-1">
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400/60">Best Score</span>
          </div>
          <span className="text-2xl sm:text-3xl font-bold font-mono tracking-tight text-amber-300 mt-1 select-none transition-all duration-200 group-hover:scale-105">
            {highScore}
          </span>
        </div>
      </div>

      {/* 3. Streak Bento Card (PRD Requirement) */}
      {streak > 0 && (
        <div 
          id="streak-gauge-container"
          className="w-full bg-orange-500/5 border border-orange-500/20 rounded-2xl p-3 px-4 flex items-center justify-between gap-3 relative overflow-hidden group hover:border-orange-500/30 hover:bg-orange-500/10 transition-all duration-300 shadow-md"
        >
          <div className="absolute top-0 right-0 w-16 h-16 bg-orange-500/15 rounded-full blur-xl pointer-events-none animate-pulse" />
          
          <div className="flex items-center gap-2.5">
            <div className="relative">
              <Flame className="w-5.5 h-5.5 text-orange-500 fill-orange-500 animate-bounce" />
              <div className="absolute inset-0 bg-orange-500/35 rounded-full filter blur-md animate-ping" />
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-bold text-orange-400 font-display uppercase tracking-wide">
                STREAK {streak}x!
              </span>
              <span className="text-[9px] text-slate-400 font-mono">
                +{streakMultiplier * 50} pts/clear bonus
              </span>
            </div>
          </div>

          {/* Visual Bar showing Streak Power */}
          <div className="flex-1 max-w-[130px] h-2 bg-slate-950/80 rounded-full overflow-hidden border border-white/5">
            <div 
              className="h-full bg-gradient-to-r from-orange-500 via-rose-500 to-yellow-400 rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, streak * 20)}%` }}
            />
          </div>
        </div>
      )}

      {/* 4. Clear Bonus Level Bento Card */}
      {clearBonusLevel > 1 && (
        <div 
          id="clear-bonus-gauge-container"
          className="w-full bg-emerald-500/5 border border-emerald-500/20 rounded-2xl p-3 px-4 flex items-center justify-between gap-3 mt-3 relative overflow-hidden group hover:border-emerald-500/30 hover:bg-emerald-500/10 transition-all duration-300 shadow-md"
        >
          <div className="absolute top-0 right-0 w-16 h-16 bg-emerald-500/15 rounded-full blur-xl pointer-events-none animate-pulse" />
          
          <div className="flex items-center gap-2.5">
            <span className="text-xl select-none animate-pulse">✨</span>
            <div className="flex flex-col">
              <span className="text-sm font-bold text-emerald-400 font-display uppercase tracking-wide">
                CLEAR LVL {clearBonusLevel}!
              </span>
              <span className="text-[9px] text-slate-400 font-mono">
                Combo score is boosted to <strong className="text-emerald-300">{(1 + (clearBonusLevel - 1) * 0.5).toFixed(1)}x</strong>!
              </span>
            </div>
          </div>

          <div className="text-[9px] font-semibold text-emerald-300 px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full select-none animate-pulse">
            +{(clearBonusLevel - 1) * 50}%
          </div>
        </div>
      )}
    </div>
  );
};

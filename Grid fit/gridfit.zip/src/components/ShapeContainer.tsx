/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ActiveShape, ShapeTemplate } from '../types';
import { getFruitForColor } from '../lib/shapes';
import { DEFAULT_SKINS } from '../lib/fruitSkins';
import { FruitCell } from './FruitCell';

interface ShapeContainerProps {
  activeShapes: ActiveShape[];
  selectedShapeId: string | null;
  isFruitTheme: boolean;
  selectedSkins: Record<string, string>;
  onSelectShape: (id: string, template: ShapeTemplate) => void;
  onPointerDownShape: (e: React.PointerEvent, id: string, template: ShapeTemplate) => void;
}

export const ShapeContainer: React.FC<ShapeContainerProps> = ({
  activeShapes,
  selectedShapeId,
  isFruitTheme,
  selectedSkins,
  onSelectShape,
  onPointerDownShape,
}) => {
  return (
    <div 
      id="gridfit-shape-dock"
      className="w-full flex justify-around items-center gap-3 relative min-h-[120px]"
    >
      {activeShapes.map((activeShape) => {
        const { id, template, used } = activeShape;

        if (used) {
          // Render an empty slot as a clean bento slot with a soft placeholder circle
          return (
            <div
              key={id}
              className="flex-1 aspect-square max-w-[110px] flex items-center justify-center border border-dashed border-white/10 rounded-2xl bg-slate-950/40 shadow-inner"
            >
              <div className="w-3.5 h-3.5 rounded-full bg-white/5 animate-pulse" />
            </div>
          );
        }

        const isSelected = selectedShapeId === id;
        
        // Custom scale & layout for shape dock
        // Limit maximum size so larger shapes don't overflow their slot
        const maxBlockSize = template.width > 4 || template.height > 4 ? 14 : 18;

        const skinId = isFruitTheme ? (selectedSkins[template.name] || DEFAULT_SKINS[template.name]) : '';

        return (
          <div
            key={id}
            id={`shape-slot-${id}`}
            onClick={(e) => {
              e.stopPropagation();
              onSelectShape(id, template);
            }}
            onPointerDown={(e) => {
              // Only trigger dragging with left click
              if (e.button !== 0) return;
              onPointerDownShape(e, id, template);
            }}
            className={`flex-1 aspect-square max-w-[110px] flex flex-col items-center justify-center p-2 rounded-2xl transition-all duration-300 cursor-grab active:cursor-grabbing select-none relative border shadow-lg
              ${isSelected 
                ? 'ring-2 ring-yellow-400 bg-slate-800 border-yellow-400/40 scale-105 shadow-yellow-500/10' 
                : 'bg-slate-900/65 border-white/10 hover:bg-slate-850 hover:scale-[1.05] hover:border-white/20 active:scale-[0.98]'
              }`}
            style={{ touchAction: 'none' }} // Crucial for mobile pointer dragging
          >
            {/* Shape Grid Display */}
            <div
              className="grid gap-[2px] justify-center items-center"
              style={{
                gridTemplateColumns: `repeat(${template.width}, minmax(0, 1fr))`,
                gridTemplateRows: `repeat(${template.height}, minmax(0, 1fr))`,
              }}
            >
              {Array.from({ length: template.height }).map((_, r) => {
                return Array.from({ length: template.width }).map((_, c) => {
                  const hasBlock = template.blocks.some((b) => b.row === r && b.col === c);

                  if (!hasBlock) {
                    return <div key={`${r}-${c}`} className="w-[14px] h-[14px] sm:w-[18px] sm:h-[18px] opacity-0" />;
                  }

                  return (
                    <div
                      key={`${r}-${c}`}
                      className="rounded-[4px] border-t border-white/20 shadow-md block-glow relative overflow-hidden"
                      style={{
                        width: `${maxBlockSize}px`,
                        height: `${maxBlockSize}px`,
                        backgroundColor: skinId ? undefined : template.color,
                        borderColor: skinId ? 'transparent' : 'rgba(255, 255, 255, 0.25)',
                        ['--glow-color' as any]: `${template.color}40`,
                      }}
                    >
                      {isFruitTheme && skinId ? (
                        <FruitCell
                          skinId={skinId}
                          row={r}
                          col={c}
                          width={template.width}
                          height={template.height}
                          color={template.color}
                          cellSize={maxBlockSize}
                        />
                      ) : (
                        <>
                          {/* Sub-shiny sheen layer */}
                          <div className="absolute inset-x-0 top-0 h-[35%] bg-gradient-to-b from-white/20 to-transparent rounded-t-[2px]" />
                          {isFruitTheme && (
                            <span 
                              style={{ fontSize: `${maxBlockSize * 0.8}px` }}
                              className="select-none leading-none z-10 flex items-center justify-center h-full w-full"
                            >
                              {getFruitForColor(template.color).emoji}
                            </span>
                          )}
                        </>
                      )}
                    </div>
                  );
                });
              })}
            </div>

            {/* Subtle help tag */}
            <div className="absolute bottom-1.5 text-[8px] tracking-wider text-white/35 font-mono uppercase hidden sm:block">
              {template.name.replace('Pentomino ', 'P-').replace('Tetromino ', 'T-')}
            </div>
          </div>
        );
      })}
    </div>
  );
};

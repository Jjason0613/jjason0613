/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

interface FruitCellProps {
  skinId: string;
  row: number;      // Local row index within the shape template
  col: number;      // Local col index within the shape template
  width: number;    // Shape total width in cells
  height: number;   // Shape total height in cells
  color?: string;   // Fallback color
  cellSize?: number;// Optional cell size
}

export const FruitCell: React.FC<FruitCellProps> = ({
  skinId,
  row,
  col,
  width,
  height,
  color = '#eab308',
  cellSize = 36,
}) => {
  // Let's render the detailed vector graphics for each skin ID
  switch (skinId) {
    // =========================================================================
    // O-BLOCK SKINS (2x2)
    // =========================================================================
    case 'lemon_wheel': {
      // 2x2 Segmented Meyer Lemon Wheel. The center is at the junction of the 4 cells.
      // Top-left: (0,0) -> center is bottom-right (100%, 100%)
      // Top-right: (0,1) -> center is bottom-left (0%, 100%)
      // Bottom-left: (1,0) -> center is top-right (100%, 0%)
      // Bottom-right: (1,1) -> center is top-left (0%, 0%)
      const isTop = row === 0;
      const isLeft = col === 0;

      const cx = isLeft ? 100 : 0;
      const cy = isTop ? 100 : 0;
      
      return (
        <div className="absolute inset-0 bg-amber-500/90 overflow-hidden">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            {/* White rind background */}
            <circle cx={cx} cy={cy} r="95" fill="#fef08a" />
            <circle cx={cx} cy={cy} r="85" fill="#facc15" />
            {/* Outer skin/rind boundary */}
            <path
              d={isLeft 
                ? (isTop ? "M 5,100 A 95 95 0 0 1 100,5 L 100,100 Z" : "M 5,0 A 95 95 0 0 0 100,95 L 100,0 Z")
                : (isTop ? "M 0,5 A 95 95 0 0 1 95,100 L 0,100 Z" : "M 0,95 A 95 95 0 0 0 95,0 L 0,0 Z")
              }
              fill="#eab308"
              stroke="#ca8a04"
              strokeWidth="2"
            />
            {/* White pith circle */}
            <circle cx={cx} cy={cy} r="88" fill="none" stroke="#fef08a" strokeWidth="4" />
            {/* Radial segmented segments */}
            {isTop && isLeft && (
              <>
                <path d="M 100,100 L 15,65 A 85 85 0 0 1 35,45 Z" fill="#fef08a" opacity="0.3" />
                <path d="M 100,100 L 15,70 A 82 82 0 0 1 30,50 Z" fill="#eab308" />
                <path d="M 100,100 L 40,35 A 85 85 0 0 1 65,15 Z" fill="#eab308" />
              </>
            )}
            {!isTop && isLeft && (
              <>
                <path d="M 100,0 L 15,35 A 85 85 0 0 0 35,55 Z" fill="#eab308" />
                <path d="M 100,0 L 40,65 A 85 85 0 0 0 65,85 Z" fill="#eab308" />
              </>
            )}
            {isTop && !isLeft && (
              <>
                <path d="M 0,100 L 85,65 A 85 85 0 0 0 65,45 Z" fill="#eab308" />
                <path d="M 0,100 L 60,35 A 85 85 0 0 0 35,15 Z" fill="#eab308" />
              </>
            )}
            {!isTop && !isLeft && (
              <>
                <path d="M 0,0 L 85,35 A 85 85 0 0 1 65,55 Z" fill="#eab308" />
                <path d="M 0,0 L 60,65 A 85 85 0 0 1 35,85 Z" fill="#eab308" />
              </>
            )}
            {/* Center soft node */}
            <circle cx={cx} cy={cy} r="12" fill="#fff" opacity="0.9" />
          </svg>
        </div>
      );
    }

    case 'pineapple_ring': {
      // 2x2 golden pineapple ring.
      const isTop = row === 0;
      const isLeft = col === 0;
      const cx = isLeft ? 100 : 0;
      const cy = isTop ? 100 : 0;

      return (
        <div className="absolute inset-0 bg-yellow-500/80 overflow-hidden">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            {/* Outer golden textured disk */}
            <circle cx={cx} cy={cy} r="95" fill="#fbbf24" stroke="#d97706" strokeWidth="4" />
            <circle cx={cx} cy={cy} r="85" fill="#facc15" />
            {/* Fibrous radiating pattern */}
            <line x1={cx} y1={cy} x2={isLeft ? 20 : 80} y2={isTop ? 20 : 80} stroke="#d97706" strokeWidth="2.5" strokeDasharray="3 4" />
            <line x1={cx} y1={cy} x2={isLeft ? 40 : 60} y2={isTop ? 10 : 90} stroke="#d97706" strokeWidth="2.5" strokeDasharray="3 4" />
            <line x1={cx} y1={cy} x2={isLeft ? 10 : 90} y2={isTop ? 40 : 60} stroke="#d97706" strokeWidth="2.5" strokeDasharray="3 4" />
            {/* Core cutout ring (hollow dark center) */}
            <circle cx={cx} cy={cy} r="35" fill="#451a03" stroke="#f59e0b" strokeWidth="3" />
            <circle cx={cx} cy={cy} r="28" fill="#1e293b" />
          </svg>
        </div>
      );
    }

    case 'banana_slices': {
      // Four complete distinct banana slices grid, one per cell
      return (
        <div className="absolute inset-0 bg-amber-100 flex items-center justify-center rounded-md p-1 border border-amber-300">
          <svg className="w-[85%] h-[85%]" viewBox="0 0 100 100">
            {/* Yellow outer peel rind */}
            <circle cx="50" cy="50" r="48" fill="#fef08a" stroke="#eab308" strokeWidth="4" />
            {/* Inner soft cream pulp */}
            <circle cx="50" cy="50" r="42" fill="#fffbeb" />
            {/* Core star lines */}
            <path d="M 50,50 L 50,38 M 50,50 L 39,56 M 50,50 L 61,56" stroke="#ca8a04" strokeWidth="1.5" strokeLinecap="round" opacity="0.4" />
            {/* Banana tiny central seeds */}
            <circle cx="48" cy="45" r="3.5" fill="#713f12" />
            <circle cx="53" cy="48" r="3" fill="#713f12" />
            <circle cx="47" cy="52" r="3.5" fill="#713f12" />
            <circle cx="52" cy="54" r="2.5" fill="#713f12" />
          </svg>
        </div>
      );
    }

    // =========================================================================
    // I-BLOCK SKINS (1x4)
    // =========================================================================
    case 'blueberry_skewer':
    case 'blueberry_skewer_v': {
      // Giant, plump highbush blueberries
      return (
        <div className="absolute inset-0 bg-slate-900/40 flex items-center justify-center p-1">
          <svg className="w-[90%] h-[90%]" viewBox="0 0 100 100">
            {/* Ambient shadow */}
            <circle cx="51" cy="52" r="44" fill="#000" opacity="0.4" />
            {/* Blueberry body */}
            <defs>
              <radialGradient id="blueGlow" cx="35%" cy="35%" r="65%">
                <stop offset="0%" stopColor="#38bdf8" />
                <stop offset="40%" stopColor="#2563eb" />
                <stop offset="85%" stopColor="#1e3a8a" />
                <stop offset="100%" stopColor="#0f172a" />
              </radialGradient>
            </defs>
            <circle cx="50" cy="50" r="44" fill="url(#blueGlow)" stroke="#1d4ed8" strokeWidth="2" />
            {/* Dusty Bloom frost layer */}
            <circle cx="50" cy="50" r="44" fill="#60a5fa" opacity="0.15" />
            {/* Blueberry crown (calyx) */}
            <path d="M 42,42 L 50,34 L 58,42 L 66,50 L 58,58 L 50,66 L 42,58 L 34,50 Z" fill="#1e1b4b" stroke="#1d4ed8" strokeWidth="1" />
            <circle cx="50" cy="50" r="10" fill="#0f172a" />
            {/* Crown points */}
            <path d="M 50,38 L 50,44 M 50,62 L 50,56 M 38,50 L 44,50 M 62,50 L 56,50" stroke="#3b82f6" strokeWidth="2.5" strokeLinecap="round" />
            {/* Specular highlight */}
            <ellipse cx="34" cy="34" rx="8" ry="4" transform="rotate(-30 34 34)" fill="#fff" opacity="0.6" />
          </svg>
        </div>
      );
    }

    case 'blue_java_banana_h': {
      const isFirst = col === 0;
      const isLast = col === 3;
      return (
        <div className="absolute inset-0 bg-slate-950/20 p-[2px]">
          <div className={`w-full h-full bg-gradient-to-b from-sky-100 via-sky-50 to-sky-200 border-y-2 border-sky-300 flex flex-col justify-center items-center relative overflow-hidden ${
            isFirst ? 'rounded-l-2xl border-l-2' : ''
          } ${
            isLast ? 'rounded-r-2xl border-r-2' : ''
          }`}>
            {/* Center core segment */}
            <div className="w-full h-[6px] bg-sky-200/50 absolute" />
            {/* Scattered small black banana seeds */}
            <div className="flex gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-slate-700/80 animate-pulse" />
              <div className="w-1 h-1 rounded-full bg-slate-600/80" />
            </div>
          </div>
        </div>
      );
    }

    case 'blue_java_banana_v': {
      const isFirst = row === 0;
      const isLast = row === 3;
      return (
        <div className="absolute inset-0 bg-slate-950/20 p-[2px]">
          <div className={`w-full h-full bg-gradient-to-r from-sky-100 via-sky-50 to-sky-200 border-x-2 border-sky-300 flex flex-row justify-center items-center relative overflow-hidden ${
            isFirst ? 'rounded-t-2xl border-t-2' : ''
          } ${
            isLast ? 'rounded-b-2xl border-b-2' : ''
          }`}>
            {/* Center core segment */}
            <div className="h-full w-[6px] bg-sky-200/50 absolute" />
            {/* Scattered small black banana seeds */}
            <div className="flex flex-col gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-slate-700/80 animate-pulse" />
              <div className="w-1 h-1 rounded-full bg-slate-600/80" />
            </div>
          </div>
        </div>
      );
    }

    case 'blackberry_column_h':
    case 'blackberry_column_v': {
      // Cluster of shiny blackberry drupelets
      return (
        <div className="absolute inset-0 bg-slate-950 flex items-center justify-center p-[2px] rounded-md">
          <div className="w-full h-full grid grid-cols-2 grid-rows-2 gap-[1px]">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="w-full h-full bg-gradient-to-br from-purple-800 via-violet-950 to-slate-950 rounded-full relative overflow-hidden border border-purple-900/40">
                <div className="w-2 h-1 bg-white/40 rounded-full absolute top-[15%] left-[20%] transform rotate-[-20deg]" />
              </div>
            ))}
          </div>
        </div>
      );
    }

    // =========================================================================
    // S-BLOCK & Z-BLOCK SKINS (3x2 staggered)
    // =========================================================================
    case 'strawberry': {
      // Red heart-shaped strawberry slices
      return (
        <div className="absolute inset-0 bg-slate-950/30 flex items-center justify-center p-0.5">
          <svg className="w-[95%] h-[95%]" viewBox="0 0 100 100">
            {/* Strawberry base */}
            <path d="M 50,95 C 10,75 5,45 15,25 C 25,5 45,8 50,15 C 55,8 75,5 85,25 C 95,45 90,75 50,95 Z" fill="#ef4444" stroke="#b91c1c" strokeWidth="2.5" />
            {/* Heart pulp center ring (white/pink) */}
            <path d="M 50,85 C 25,70 20,48 26,34 C 32,20 45,22 50,28 C 55,22 68,20 74,34 C 80,48 75,70 50,85 Z" fill="#fee2e2" opacity="0.8" />
            <path d="M 50,82 C 30,68 25,48 30,36 C 35,24 45,26 50,32 C 55,26 65,24 70,36 C 75,48 70,68 50,82 Z" fill="#fecaca" />
            {/* Green leaf cap */}
            <path d="M 50,15 L 35,2 L 42,12 L 50,0 L 58,12 L 65,2 Z" fill="#22c55e" stroke="#15803d" strokeWidth="1.5" />
            {/* Tiny seeds (achenes) */}
            <circle cx="32" cy="45" r="2" fill="#facc15" />
            <circle cx="68" cy="45" r="2" fill="#facc15" />
            <circle cx="42" cy="62" r="2" fill="#facc15" />
            <circle cx="58" cy="62" r="2" fill="#facc15" />
            <circle cx="50" cy="74" r="2" fill="#facc15" />
            <circle cx="50" cy="48" r="2.2" fill="#facc15" />
          </svg>
        </div>
      );
    }

    case 'bing_cherry': {
      return (
        <div className="absolute inset-0 bg-rose-950/40 flex items-center justify-center p-1">
          <svg className="w-[90%] h-[90%]" viewBox="0 0 100 100">
            {/* Glossy crimson cherry body */}
            <circle cx="50" cy="50" r="45" fill="#881337" stroke="#4c0519" strokeWidth="3" />
            <circle cx="50" cy="50" r="38" fill="#9f1239" />
            {/* Highlight */}
            <ellipse cx="32" cy="30" rx="9" ry="5" transform="rotate(-25 32 30)" fill="#fff" opacity="0.6" />
            {/* Center pit cutout indentation */}
            <circle cx="50" cy="50" r="14" fill="#31040e" />
            <circle cx="50" cy="50" r="8" fill="#1c0006" />
          </svg>
        </div>
      );
    }

    case 'kiwi_crosscut': {
      return (
        <div className="absolute inset-0 bg-lime-950/20 flex items-center justify-center p-0.5">
          <svg className="w-[95%] h-[95%]" viewBox="0 0 100 100">
            {/* Kiwi Brown fuzzy rind */}
            <circle cx="50" cy="50" r="48" fill="#854d0e" stroke="#713f12" strokeWidth="2.5" />
            {/* Bright emerald green pulp */}
            <circle cx="50" cy="50" r="43" fill="#22c55e" />
            {/* Creamy white central core */}
            <ellipse cx="50" cy="50" rx="16" ry="12" fill="#fef08a" opacity="0.9" />
            {/* Radiating fine fiber lines */}
            <line x1="50" y1="50" x2="20" y2="25" stroke="#fff" strokeWidth="1" opacity="0.4" />
            <line x1="50" y1="50" x2="80" y2="25" stroke="#fff" strokeWidth="1" opacity="0.4" />
            <line x1="50" y1="50" x2="20" y2="75" stroke="#fff" strokeWidth="1" opacity="0.4" />
            <line x1="50" y1="50" x2="80" y2="75" stroke="#fff" strokeWidth="1" opacity="0.4" />
            <line x1="50" y1="50" x2="50" y2="10" stroke="#fff" strokeWidth="1" opacity="0.4" />
            <line x1="50" y1="50" x2="50" y2="90" stroke="#fff" strokeWidth="1" opacity="0.4" />
            {/* Concentric ring of black seeds */}
            <circle cx="36" cy="40" r="2" fill="#172554" />
            <circle cx="64" cy="40" r="2" fill="#172554" />
            <circle cx="36" cy="60" r="2" fill="#172554" />
            <circle cx="64" cy="60" r="2" fill="#172554" />
            <circle cx="50" cy="34" r="2" fill="#172554" />
            <circle cx="50" cy="66" r="2" fill="#172554" />
            <circle cx="32" cy="50" r="2" fill="#172554" />
            <circle cx="68" cy="50" r="2" fill="#172554" />
          </svg>
        </div>
      );
    }

    case 'lime_slices': {
      return (
        <div className="absolute inset-0 bg-emerald-500/80 flex items-center justify-center p-0.5">
          <svg className="w-[95%] h-[95%]" viewBox="0 0 100 100">
            {/* Lime dark rind */}
            <circle cx="50" cy="50" r="48" fill="#16a34a" stroke="#15803d" strokeWidth="2.5" />
            {/* White pith circle */}
            <circle cx="50" cy="50" r="43" fill="#bbf7d0" />
            {/* Lime segments */}
            <path d="M 50,50 L 22,25 A 38 38 0 0 1 50,12 Z" fill="#4ade80" />
            <path d="M 50,50 L 50,12 A 38 38 0 0 1 78,25 Z" fill="#22c55e" />
            <path d="M 50,50 L 78,25 A 38 38 0 0 1 88,50 Z" fill="#4ade80" />
            <path d="M 50,50 L 88,50 A 38 38 0 0 1 78,75 Z" fill="#22c55e" />
            <path d="M 50,50 L 78,75 A 38 38 0 0 1 50,88 Z" fill="#4ade80" />
            <path d="M 50,50 L 50,88 A 38 38 0 0 1 22,75 Z" fill="#22c55e" />
            <path d="M 50,50 L 22,75 A 38 38 0 0 1 12,50 Z" fill="#4ade80" />
            <path d="M 50,50 L 12,50 A 38 38 0 0 1 22,25 Z" fill="#22c55e" />
            {/* Center node */}
            <circle cx="50" cy="50" r="6" fill="#fff" />
          </svg>
        </div>
      );
    }

    // =========================================================================
    // L-BLOCK & J-BLOCK SKINS (Clementine / Mandarin, Mango Cubes, Dragon Fruit)
    // =========================================================================
    case 'clementine_segments':
    case 'clementine_segments_r': {
      return (
        <div className="absolute inset-0 bg-amber-500/15 flex items-center justify-center p-1">
          <svg className="w-full h-full" viewBox="0 0 100 100">
            {/* Orange crescent segment */}
            <path d="M 12,50 C 12,18 48,8 88,35 C 55,42 28,68 12,50 Z" fill="#f97316" stroke="#ea580c" strokeWidth="3" />
            {/* Juicy sacs lining */}
            <path d="M 18,48 C 18,25 45,16 75,37 C 52,42 30,62 18,48 Z" fill="#fdba74" opacity="0.6" />
          </svg>
        </div>
      );
    }

    case 'mango_cubes':
    case 'mango_cubes_r': {
      // Scored mango cubes
      return (
        <div className="absolute inset-0 bg-gradient-to-br from-amber-400 via-orange-400 to-amber-500 p-[3px] border border-orange-500 rounded-md">
          <div className="w-full h-full border-2 border-dashed border-amber-300/60 flex items-center justify-center">
            {/* Score lines inside the mango block */}
            <div className="absolute top-[30%] w-full h-[2px] bg-orange-600/30" />
            <div className="absolute top-[65%] w-full h-[2px] bg-orange-600/30" />
            <div className="absolute left-[30%] h-full w-[2px] bg-orange-600/30" />
            <div className="absolute left-[65%] h-full w-[2px] bg-orange-600/30" />
            <span className="text-[10px] text-white/40 font-mono select-none">🥭</span>
          </div>
        </div>
      );
    }

    case 'passionfruit_l':
    case 'passionfruit_r': {
      return (
        <div className="absolute inset-0 bg-slate-900/30 flex items-center justify-center p-1">
          <svg className="w-[95%] h-[95%]" viewBox="0 0 100 100">
            {/* Purple wood crust rind */}
            <circle cx="50" cy="50" r="48" fill="#4c1d95" stroke="#31105e" strokeWidth="4" />
            {/* White lining rind */}
            <circle cx="50" cy="50" r="42" fill="#fdf2f8" />
            {/* Golden jelly interior */}
            <circle cx="50" cy="50" r="37" fill="#eab308" />
            {/* Black gelatinous seeds */}
            <circle cx="38" cy="42" r="3.5" fill="#1e293b" stroke="#ca8a04" strokeWidth="1.5" />
            <circle cx="62" cy="42" r="3" fill="#1e293b" stroke="#ca8a04" strokeWidth="1.5" />
            <circle cx="44" cy="58" r="3.5" fill="#1e293b" stroke="#ca8a04" strokeWidth="1.5" />
            <circle cx="58" cy="58" r="2.5" fill="#1e293b" stroke="#ca8a04" strokeWidth="1.5" />
            <circle cx="50" cy="45" r="3" fill="#1e293b" stroke="#ca8a04" strokeWidth="1.5" />
          </svg>
        </div>
      );
    }

    case 'papaya_boats_l':
    case 'papaya_boats_r': {
      return (
        <div className="absolute inset-0 flex items-center justify-center p-0.5">
          <svg className="w-full h-full" viewBox="0 0 100 100">
            {/* Papaya skin rind */}
            <path d="M 5,50 C 5,20 95,20 95,50 C 95,80 5,80 5,50 Z" fill="#eab308" stroke="#ca8a04" strokeWidth="2" />
            {/* Juicy orange flesh */}
            <path d="M 12,50 C 12,28 88,28 88,50 C 88,72 12,72 12,50 Z" fill="#f97316" />
            {/* Core pocket with tiny seed dots */}
            <path d="M 30,50 C 30,40 70,40 70,50 C 70,60 30,60 30,50 Z" fill="#431407" />
            <circle cx="45" cy="48" r="2" fill="#000" />
            <circle cx="55" cy="52" r="1.8" fill="#000" />
            <circle cx="38" cy="51" r="2" fill="#000" />
            <circle cx="62" cy="49" r="1.5" fill="#000" />
          </svg>
        </div>
      );
    }

    // =========================================================================
    // T-BLOCK SKINS (Plum, Blackberry Mosaic)
    // =========================================================================
    case 'plum_slices': {
      return (
        <div className="absolute inset-0 bg-violet-950/40 flex items-center justify-center p-0.5">
          <svg className="w-[95%] h-[95%]" viewBox="0 0 100 100">
            {/* Royal purple skin */}
            <circle cx="50" cy="50" r="48" fill="#581c87" stroke="#3b0764" strokeWidth="3" />
            {/* Juicy golden flesh ring */}
            <circle cx="50" cy="50" r="38" fill="#eab308" />
            <circle cx="50" cy="50" r="30" fill="#facc15" />
            {/* Pit well */}
            <circle cx="50" cy="50" r="12" fill="#7c2d12" />
          </svg>
        </div>
      );
    }

    case 'blackberry_mosaic': {
      return (
        <div className="absolute inset-0 bg-violet-950 flex items-center justify-center p-[2px] rounded-lg">
          <div className="w-full h-full grid grid-cols-2 grid-rows-2 gap-[1px]">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="w-full h-full bg-gradient-to-br from-violet-900 via-fuchsia-950 to-slate-950 rounded-full border border-violet-800/40" />
            ))}
          </div>
        </div>
      );
    }

    // =========================================================================
    // 1x1 DOT SKINS
    // =========================================================================
    case 'wild_raspberry': {
      return (
        <div className="absolute inset-0 bg-rose-950/20 flex items-center justify-center p-0.5">
          <svg className="w-[90%] h-[90%]" viewBox="0 0 100 100">
            {/* Raspberry shape */}
            <path d="M 50,92 C 20,80 15,50 20,32 C 25,14 45,14 50,22 C 55,14 75,14 80,32 C 85,50 80,80 50,92 Z" fill="#e11d48" stroke="#9f1239" strokeWidth="2.5" />
            {/* Micro segments representation */}
            <circle cx="34" cy="40" r="10" fill="#fb7185" opacity="0.3" />
            <circle cx="66" cy="40" r="10" fill="#fb7185" opacity="0.3" />
            <circle cx="50" cy="64" r="12" fill="#be123c" />
            <circle cx="50" cy="44" r="10" fill="#be123c" />
            {/* Tiny green leaf handle */}
            <path d="M 50,22 L 45,5 L 50,12 L 55,5 Z" fill="#16a34a" />
          </svg>
        </div>
      );
    }

    case 'kumquat_round': {
      return (
        <div className="absolute inset-0 bg-amber-500/80 flex items-center justify-center p-0.5">
          <svg className="w-[95%] h-[95%]" viewBox="0 0 100 100">
            {/* Kumquat sweet orange rind */}
            <ellipse cx="50" cy="50" rx="48" ry="40" fill="#f97316" stroke="#ea580c" strokeWidth="3" />
            {/* Inner pith and pulp */}
            <ellipse cx="50" cy="50" rx="40" ry="32" fill="#ffedd5" />
            <ellipse cx="50" cy="50" rx="36" ry="28" fill="#fb923c" />
            {/* Segment dividing lines */}
            <line x1="50" y1="50" x2="14" y2="50" stroke="#ffedd5" strokeWidth="2" />
            <line x1="50" y1="50" x2="86" y2="50" stroke="#ffedd5" strokeWidth="2" />
            <line x1="50" y1="50" x2="30" y2="30" stroke="#ffedd5" strokeWidth="2" />
            <line x1="50" y1="50" x2="70" y2="70" stroke="#ffedd5" strokeWidth="2" />
          </svg>
        </div>
      );
    }

    // =========================================================================
    // 1x2 DOMINO SKINS (Apricot, Fig, Plum, Kiwiberry)
    // =========================================================================
    case 'apricot_slabs': {
      return (
        <div className="absolute inset-0 bg-amber-500/30 flex items-center justify-center p-0.5">
          <svg className="w-[95%] h-[95%]" viewBox="0 0 100 100">
            {/* Velvety golden apricot */}
            <circle cx="50" cy="50" r="46" fill="#f59e0b" stroke="#d97706" strokeWidth="2.5" />
            {/* Shaded crease line */}
            <path d="M 50,4 C 40,30 40,70 50,96" stroke="#b45309" strokeWidth="2.5" fill="none" opacity="0.3" />
            {/* Center stone cavity */}
            <circle cx="50" cy="50" r="12" fill="#78350f" opacity="0.8" />
          </svg>
        </div>
      );
    }

    case 'fig_crosscut': {
      return (
        <div className="absolute inset-0 bg-indigo-950/40 flex items-center justify-center p-0.5">
          <svg className="w-[95%] h-[95%]" viewBox="0 0 100 100">
            {/* Deep purple fig skin */}
            <circle cx="50" cy="50" r="46" fill="#4a044e" stroke="#2e0854" strokeWidth="2.5" />
            {/* White rind outline */}
            <circle cx="50" cy="50" r="41" fill="#fdf2f8" />
            {/* Sweet ruby seed center */}
            <circle cx="50" cy="50" r="35" fill="#ec4899" />
            {/* Seed specks */}
            <circle cx="42" cy="42" r="1.5" fill="#fdf2f8" />
            <circle cx="58" cy="42" r="1.5" fill="#fdf2f8" />
            <circle cx="44" cy="58" r="1.5" fill="#fdf2f8" />
            <circle cx="56" cy="58" r="1.5" fill="#fdf2f8" />
            <circle cx="50" cy="50" r="2" fill="#fdf2f8" />
          </svg>
        </div>
      );
    }

    case 'plum_halves': {
      return (
        <div className="absolute inset-0 bg-purple-950/20 flex items-center justify-center p-0.5">
          <svg className="w-[95%] h-[95%]" viewBox="0 0 100 100">
            {/* Plum skin */}
            <circle cx="50" cy="50" r="46" fill="#6b21a8" stroke="#4a044e" strokeWidth="2.5" />
            {/* Shaded vertical crease */}
            <path d="M 50,4 Q 45,50 50,96" stroke="#4a044e" strokeWidth="2" fill="none" opacity="0.5" />
            {/* Highlight */}
            <ellipse cx="32" cy="32" rx="7" ry="4" transform="rotate(-30 32 32)" fill="#fff" opacity="0.5" />
          </svg>
        </div>
      );
    }

    case 'kiwiberry_pillar': {
      return (
        <div className="absolute inset-0 bg-emerald-900/10 flex items-center justify-center p-0.5">
          <svg className="w-[95%] h-[95%]" viewBox="0 0 100 100">
            {/* Smooth baby kiwiberry green skin */}
            <circle cx="50" cy="50" r="46" fill="#15803d" stroke="#166534" strokeWidth="2" />
            <circle cx="50" cy="50" r="40" fill="#22c55e" />
            {/* Light green starburst core */}
            <circle cx="50" cy="50" r="14" fill="#86efac" opacity="0.9" />
            {/* Seed ring */}
            <circle cx="40" cy="42" r="1.5" fill="#000" />
            <circle cx="60" cy="42" r="1.5" fill="#000" />
            <circle cx="42" cy="58" r="1.5" fill="#000" />
            <circle cx="58" cy="58" r="1.5" fill="#000" />
          </svg>
        </div>
      );
    }

    // =========================================================================
    // 1x3 TRIO SKINS (Starfruit, Guava)
    // =========================================================================
    case 'starfruit_slices_h':
    case 'starfruit_slices_v': {
      return (
        <div className="absolute inset-0 bg-yellow-400/20 flex items-center justify-center p-0.5">
          <svg className="w-[95%] h-[95%]" viewBox="0 0 100 100">
            {/* Star shaped path */}
            <path
              d="M 50,5 L 63,33 L 95,35 L 70,55 L 78,87 L 50,70 L 22,87 L 30,55 L 5,35 L 37,33 Z"
              fill="#fb923c"
              stroke="#84cc16"
              strokeWidth="4.5"
            />
            <path
              d="M 50,8 L 61,34 L 91,36 L 68,54 L 75,84 L 50,68 L 25,84 L 32,54 L 9,36 L 39,34 Z"
              fill="#facc15"
            />
            {/* Center star starburst */}
            <path
              d="M 50,50 L 50,30 M 50,50 L 65,40 M 50,50 L 60,60 M 50,50 L 40,60 M 50,50 L 35,40"
              stroke="#fff"
              strokeWidth="2.5"
              strokeLinecap="round"
              opacity="0.6"
            />
            <circle cx="50" cy="50" r="5" fill="#84cc16" />
          </svg>
        </div>
      );
    }

    case 'guava_segments_h':
    case 'guava_segments_v': {
      return (
        <div className="absolute inset-0 bg-emerald-500/20 flex items-center justify-center p-0.5">
          <svg className="w-[95%] h-[95%]" viewBox="0 0 100 100">
            {/* Green outer rind */}
            <circle cx="50" cy="50" r="47" fill="#4ade80" stroke="#16a34a" strokeWidth="2.5" />
            {/* Light yellow inner pulp transition rind */}
            <circle cx="50" cy="50" r="41" fill="#fef08a" />
            {/* Rich pink/ruby guava meat */}
            <circle cx="50" cy="50" r="35" fill="#f43f5e" />
            {/* Tiny golden seed clusters */}
            <circle cx="44" cy="44" r="2.2" fill="#fbbf24" />
            <circle cx="56" cy="44" r="2" fill="#fbbf24" />
            <circle cx="42" cy="56" r="1.8" fill="#fbbf24" />
            <circle cx="58" cy="56" r="2.2" fill="#fbbf24" />
          </svg>
        </div>
      );
    }

    // =========================================================================
    // 1x5 POMEGRANATE & SUGARCANE SKINS
    // =========================================================================
    case 'pomegranate_arils_h':
    case 'pomegranate_arils_v': {
      return (
        <div className="absolute inset-0 bg-red-950/40 flex items-center justify-center p-0.5">
          <svg className="w-[90%] h-[90%]" viewBox="0 0 100 100">
            {/* Jewel-like angular red seed */}
            <path
              d="M 50,5 L 88,25 L 95,65 L 50,95 L 8,65 L 12,25 Z"
              fill="#be123c"
              stroke="#881337"
              strokeWidth="3"
            />
            {/* Internal bright glowing ruby gradient effect */}
            <path
              d="M 50,15 L 78,31 L 82,60 L 50,82 L 18,60 L 22,31 Z"
              fill="#f43f5e"
              opacity="0.9"
            />
            {/* Facet highlight */}
            <polygon points="50,15 78,31 50,50" fill="#fda4af" opacity="0.6" />
            {/* Bright specular dot */}
            <circle cx="35" cy="30" r="6" fill="#fff" opacity="0.8" />
          </svg>
        </div>
      );
    }

    case 'sugarcane_joint_h': {
      const isFirst = col === 0;
      const isLast = col === 4;
      return (
        <div className="absolute inset-0 bg-slate-950/20 p-[2px]">
          <div className={`w-full h-full bg-gradient-to-b from-lime-300 via-emerald-200 to-lime-400 border-y-2 border-emerald-500 relative overflow-hidden flex items-center justify-between ${
            isFirst ? 'rounded-l-lg border-l-2' : ''
          } ${
            isLast ? 'rounded-r-lg border-r-2' : ''
          }`}>
            {/* Node lines (joints of cane) */}
            {isFirst && <div className="absolute left-0 w-[4px] h-full bg-emerald-700/60" />}
            <div className="absolute right-0 w-[3px] h-full bg-emerald-800/50" />
            <div className="absolute right-[2px] w-[1px] h-full bg-white/40" />
            {/* Cane grain lines */}
            <div className="w-full h-[1.5px] bg-emerald-600/20 absolute top-[30%]" />
            <div className="w-full h-[1.5px] bg-emerald-600/20 absolute top-[70%]" />
          </div>
        </div>
      );
    }

    case 'sugarcane_joint_v': {
      const isFirst = row === 0;
      const isLast = row === 4;
      return (
        <div className="absolute inset-0 bg-slate-950/20 p-[2px]">
          <div className={`w-full h-full bg-gradient-to-r from-lime-300 via-emerald-200 to-lime-400 border-x-2 border-emerald-500 relative overflow-hidden flex flex-col items-center justify-between ${
            isFirst ? 'rounded-t-lg border-t-2' : ''
          } ${
            isLast ? 'rounded-b-lg border-b-2' : ''
          }`}>
            {/* Node lines (joints of cane) */}
            {isFirst && <div className="absolute top-0 h-[4px] w-full bg-emerald-700/60" />}
            <div className="absolute bottom-0 h-[3px] w-full bg-emerald-800/50" />
            <div className="absolute bottom-[2px] h-[1px] w-full bg-white/40" />
            {/* Cane grain lines */}
            <div className="h-full w-[1.5px] bg-emerald-600/20 absolute left-[30%]" />
            <div className="h-full w-[1.5px] bg-emerald-600/20 absolute left-[70%]" />
          </div>
        </div>
      );
    }

    // =========================================================================
    // 3x3 BIG L-CORNER SKINS (Cantaloupe, Coconut Shells)
    // =========================================================================
    case 'cantaloupe_slices': {
      return (
        <div className="absolute inset-0 bg-amber-500/20 flex items-center justify-center p-0.5">
          <svg className="w-[95%] h-[95%]" viewBox="0 0 100 100">
            {/* Ribbed green-beige skin */}
            <circle cx="50" cy="50" r="47" fill="#84cc16" stroke="#4d7c0f" strokeWidth="2.5" />
            {/* Green transitional ring */}
            <circle cx="50" cy="50" r="41" fill="#a3e635" />
            {/* Sweet cantaloupe orange flesh */}
            <circle cx="50" cy="50" r="35" fill="#f97316" />
            {/* Rib lines radiating outwards */}
            <line x1="50" y1="50" x2="50" y2="5" stroke="#78350f" strokeWidth="1" opacity="0.3" />
            <line x1="50" y1="50" x2="95" y2="50" stroke="#78350f" strokeWidth="1" opacity="0.3" />
            <line x1="50" y1="50" x2="5" y2="50" stroke="#78350f" strokeWidth="1" opacity="0.3" />
            <line x1="50" y1="50" x2="50" y2="95" stroke="#78350f" strokeWidth="1" opacity="0.3" />
          </svg>
        </div>
      );
    }

    case 'coconut_shells': {
      return (
        <div className="absolute inset-0 bg-slate-900/30 flex items-center justify-center p-0.5">
          <svg className="w-[95%] h-[95%]" viewBox="0 0 100 100">
            {/* Hairy brown outer coconut shell */}
            <circle cx="50" cy="50" r="47" fill="#713f12" stroke="#451a03" strokeWidth="4.5" />
            {/* White coconut meat rind */}
            <circle cx="50" cy="50" r="39" fill="#fff" stroke="#f3f4f6" strokeWidth="2" />
            {/* Liquid water center */}
            <circle cx="50" cy="50" r="23" fill="#e0f2fe" opacity="0.8" />
          </svg>
        </div>
      );
    }

    // =========================================================================
    // 3x3 CROSS SKINS (Star Apple, Jackfruit)
    // =========================================================================
    case 'star_apple': {
      // Star apple slice. The central slice has the star core.
      const isCenter = row === 1 && col === 1;
      return (
        <div className="absolute inset-0 bg-fuchsia-950/20 flex items-center justify-center p-0.5">
          <svg className="w-[95%] h-[95%]" viewBox="0 0 100 100">
            {/* Purple skin */}
            <circle cx="50" cy="50" r="47" fill="#701a75" stroke="#4a044e" strokeWidth="3" />
            {/* Cream purple flesh */}
            <circle cx="50" cy="50" r="41" fill="#fae8ff" />
            {isCenter ? (
              <>
                {/* 8-point radiating star pulp pattern inside the center block */}
                <path
                  d="M 50,15 L 53,42 L 80,30 L 58,48 L 85,65 L 54,54 L 62,80 L 50,58 L 38,80 L 46,54 L 15,65 L 42,48 L 20,30 L 47,42 Z"
                  fill="#fdf4ff"
                  stroke="#d946ef"
                  strokeWidth="1.5"
                />
                <circle cx="50" cy="50" r="8" fill="#d946ef" />
              </>
            ) : (
              // Radiating fleshy wedges for non-center cells
              <path d="M 50,50 L 30,20 A 35 35 0 0 1 70,20 Z" fill="#fdf4ff" opacity="0.6" />
            )}
          </svg>
        </div>
      );
    }

    case 'jackfruit_pods': {
      return (
        <div className="absolute inset-0 bg-yellow-500/10 flex items-center justify-center p-0.5">
          <svg className="w-[95%] h-[95%]" viewBox="0 0 100 100">
            {/* Golden fleshy jackfruit pod */}
            <path
              d="M 50,92 C 10,75 5,45 20,25 C 35,5 65,5 80,25 C 95,45 90,75 50,92 Z"
              fill="#fbbf24"
              stroke="#ca8a04"
              strokeWidth="2.5"
            />
            {/* Glossy sheen */}
            <path d="M 32,32 Q 50,15 68,32" stroke="#fff" strokeWidth="3.5" fill="none" strokeLinecap="round" opacity="0.7" />
            {/* Soft inner seed pocket shadow */}
            <ellipse cx="50" cy="55" rx="18" ry="24" fill="#ca8a04" opacity="0.25" />
          </svg>
        </div>
      );
    }

    // Default fallback to standard color block with a little symbol
    default: {
      return (
        <div 
          className="absolute inset-0 flex items-center justify-center font-mono select-none"
          style={{ backgroundColor: color }}
        >
          <div className="absolute inset-x-0 top-0 h-[35%] bg-gradient-to-b from-white/20 to-transparent rounded-t-[5px]" />
          <span style={{ fontSize: `${cellSize * 0.7}px` }}>🍌</span>
        </div>
      );
    }
  }
};
